// Cấu hình giao diện GitHub Pages — chỉ cần sửa 1 dòng dưới đây.
// Dán link /exec của bản deploy Apps Script (Deploy -> Manage deployments -> Web app URL).
window.APP_CONFIG = {
  API_URL: 'https://script.google.com/macros/s/DAN_ID_DEPLOY_VAO_DAY/exec'
};
