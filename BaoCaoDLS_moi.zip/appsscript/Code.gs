/**
 * BaoCaoDLS - Apps Script API (bản đầy đủ, giao diện chạy trên GitHub Pages)
 * - Form nhập Can thiệp DLS (ẩn/hiện ô theo Loại công việc)
 * - Form nhập Hoạt động DLS (giờ bắt đầu + thời gian)
 * - Trang báo cáo: bảng theo dược sĩ, lọc theo tháng, xuất Excel
 *
 * Cài đặt: Extensions -> Apps Script (từ chính file Google Sheet chứa dữ liệu)
 * Deploy -> New deployment -> Web app
 */

// ===== CẤU HÌNH TÊN SHEET =====
var SHEET_CANTHIEP = 'CANTHIEP_DSLS';
var SHEET_HOATDONG = 'HOATDONG_DSLS';
var SHEET_DUOCSI   = 'DM_DUOCSI';
var SHEET_KHOA     = 'DM_KHOA';
var SHEET_LOAICV   = 'DM_LOAI_CONGVIEC';
var SHEET_NOIDUNG  = 'DM_NOIDUNGCANTHIEP';
var SHEET_TTTHUOC  = 'DM_THONGTINTHUOC';
var SHEET_PHANLOAI = 'DM_PHANLOAICANTHIEP';
var SHEET_KETQUA   = 'DM_KETQUACANTHIEP';
var SHEET_TTNGOAITRU = 'TTTHUOC_NGOAITRU';   // tên TAB chứa dữ liệu ngoại trú (trong file riêng)

// ===== FILE GOOGLE SHEET RIÊNG cho "Thông tin thuốc ngoại trú" =====
// Dữ liệu ngoại trú được ghi sang MỘT FILE Google Sheet KHÁC (không nằm trong file hiện tại).
// Lần lưu đầu tiên code tự tạo file tên TEN_FILE_NGOAITRU và nhớ ID vào Script Properties để dùng lại.
// (Nếu muốn dùng file có sẵn, dán ID file vào ID_FILE_NGOAITRU bên dưới.)
var TEN_FILE_NGOAITRU = 'TTThuoc_NgoaiTru';
var ID_FILE_NGOAITRU  = '';   // để trống = tự tạo & tự nhớ; hoặc dán ID file có sẵn vào đây
var PROP_NGOAITRU_ID  = 'NGOAITRU_SS_ID';
var NGOAITRU_HEADER = ['ID','MaNS','Ngay','LoaiCongViec','Khoa','TenNVYT','TenBN','MaBN','ThuocLienQuan','LoaiThongTinThuoc','NoiDungChiTiet'];

// Lấy (hoặc tạo) TAB dữ liệu trong file ngoại trú riêng. Tự tạo file + tab + header nếu chưa có.
function getSheetNgoaiTru_() {
  var props = PropertiesService.getScriptProperties();
  var id = ID_FILE_NGOAITRU || props.getProperty(PROP_NGOAITRU_ID);
  var ss = null;
  if (id) { try { ss = SpreadsheetApp.openById(id); } catch(e){ ss = null; } }
  if (!ss) {
    ss = SpreadsheetApp.create(TEN_FILE_NGOAITRU);
    props.setProperty(PROP_NGOAITRU_ID, ss.getId());
  }
  var sh = ss.getSheetByName(SHEET_TTNGOAITRU);
  if (!sh) {
    // file mới tạo sẽ có 1 tab mặc định -> đổi tên tab đầu tiên nếu nó đang trống
    var first = ss.getSheets()[0];
    if (first && first.getLastRow() === 0) { sh = first; sh.setName(SHEET_TTNGOAITRU); }
    else { sh = ss.insertSheet(SHEET_TTNGOAITRU); }
    sh.appendRow(NGOAITRU_HEADER);
  }
  // định dạng cột Nội dung chi tiết: rộng + wrap
  var hdr = sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0].map(function(x){return String(x).trim();});
  var ndCol = hdr.indexOf('NoiDungChiTiet') + 1;
  if (ndCol > 0) { sh.setColumnWidth(ndCol, 400); sh.getRange(1, ndCol, sh.getMaxRows(), 1).setWrap(true); }
  return sh;
}

// Mở TAB dữ liệu ngoại trú ở chế độ CHỈ ĐỌC (dùng cho báo cáo) — trả null nếu file chưa tồn tại.
function openSheetNgoaiTruRO_() {
  var id = ID_FILE_NGOAITRU || PropertiesService.getScriptProperties().getProperty(PROP_NGOAITRU_ID);
  if (!id) return null;
  try { return SpreadsheetApp.openById(id).getSheetByName(SHEET_TTNGOAITRU); } catch(e){ return null; }
}

// Trả về link file ngoại trú riêng (chạy tay để lấy đường dẫn mở file).
function moFileNgoaiTru() {
  var id = ID_FILE_NGOAITRU || PropertiesService.getScriptProperties().getProperty(PROP_NGOAITRU_ID);
  if (!id) return 'Chưa có file ngoại trú (hãy lưu 1 bản ghi ngoại trú trước).';
  var url = 'https://docs.google.com/spreadsheets/d/' + id + '/edit';
  Logger.log(url);
  return url;
}

// Tên khoa Dược (loại trừ khi tính giờ đi khoa)
var KHOA_DUOC = 'Khoa Dược';

// Tên loại công việc "Huỷ thuốc" trong DM_LOAI_CONGVIEC (để đếm số lần hủy thuốc).
var LOAI_HUY_THUOC = 'Huỷ thuốc';

// ===== ĐIỂM VÀO WEB APP =====
// Giao diện nằm trên GitHub Pages; Apps Script chỉ làm API (xem Api.gs -> doPost).
function doGet() {
  return ContentService.createTextOutput(JSON.stringify({ok:true, msg:'API Bao cao DLS dang chay'}))
    .setMimeType(ContentService.MimeType.JSON);
}

// ===== DANH MỤC CHO DROPDOWN =====
function getDanhMuc() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var duocsi = [];
  var dsSheet = ss.getSheetByName(SHEET_DUOCSI);
  if (dsSheet) {
    var dsData = dsSheet.getDataRange().getValues();
    for (var i = 1; i < dsData.length; i++) {
      if (dsData[i][0]) duocsi.push({ma:String(dsData[i][0]).trim(), ten:String(dsData[i][1]).trim()});
    }
  }
  return {
    duocsi:   duocsi,
    khoa:     readOneCol(ss, SHEET_KHOA, 1),
    loaiCV:   readOneCol(ss, SHEET_LOAICV, 0),
    noiDung:  readOneCol(ss, SHEET_NOIDUNG, 0),
    ttThuoc:  readOneCol(ss, SHEET_TTTHUOC, 0),
    phanLoai: readOneCol(ss, SHEET_PHANLOAI, 0),
    ketQua:   readOneCol(ss, SHEET_KETQUA, 0),
    chuyenKhoa: readOneCol(ss, SHEET_CHUYENKHOA, 0)
  };
}

function readOneCol(ss, sheetName, colIndex) {
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) return [];
  var data = sheet.getDataRange().getValues();
  var out = [];
  for (var i = 1; i < data.length; i++) {
    var v = data[i][colIndex];
    if (v !== '' && v !== null && v !== undefined) out.push(String(v).trim());
  }
  return out;
}

// ===== LƯU CAN THIỆP =====
function luuCanThiep(form) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(SHEET_CANTHIEP);
  if (!sheet) return {ok:false, msg:'Không tìm thấy sheet ' + SHEET_CANTHIEP};

  if (!form.Ngay) return {ok:false, msg:'Vui lòng chọn Ngày'};
  if (!form.MaNS || form.MaNS.length === 0) return {ok:false, msg:'Vui lòng chọn ít nhất 1 Dược sĩ'};
  if (!form.LoaiCongViec) return {ok:false, msg:'Vui lòng chọn Loại công việc'};

  var lcv = String(form.LoaiCongViec).trim();
  if (lcv === 'Can thiệp DLS' || lcv === 'Hội chẩn DLS') {
    if (!form.LoaiCanThiep)   return {ok:false, msg:'Với "'+lcv+'" cần chọn Loại can thiệp'};
    if (!form.NoiDungChiTiet) return {ok:false, msg:'Với "'+lcv+'" cần nhập Nội dung chi tiết'};
    if (!form.KetQuaCanThiep) return {ok:false, msg:'Với "'+lcv+'" cần chọn Kết quả can thiệp'};
  }
  if (lcv === 'Thông tin thuốc') {
    if (!form.LoaiThongTinThuoc) return {ok:false, msg:'Với "Thông tin thuốc" cần chọn Loại thông tin thuốc'};
  }

  var maNS = Array.isArray(form.MaNS) ? form.MaNS.join(', ') : String(form.MaNS);
  var id = Utilities.getUuid().substring(0, 7);
  var rowObj = {
    ID:id, MaNS:maNS, Ngay:form.Ngay, LoaiCongViec:lcv,
    Khoa:form.Khoa||'', TenNVYT:form.TenNVYT||'', TenBN:form.TenBN||'', MaBN:form.MaBN||'',
    ThuocLienQuan:form.ThuocLienQuan||'', LoaiCanThiep:form.LoaiCanThiep||'',
    PhanLoaiCanThiep:form.PhanLoaiCanThiep||'', LoaiThongTinThuoc:form.LoaiThongTinThuoc||'',
    NoiDungChiTiet:form.NoiDungChiTiet||'', KetQuaCanThiep:form.KetQuaCanThiep||''
  };
  // Thông tin thuốc ngoại trú: ghi sang FILE Google Sheet RIÊNG (khác file hiện tại),
  // không ảnh hưởng đến dữ liệu/sheet CANTHIEP_DSLS cũ.
  var targetSheet = sheet;
  if (lcv === 'Thông tin thuốc ngoại trú') {
    targetSheet = getSheetNgoaiTru_();
  }

  appendByHeader(targetSheet, rowObj);
  return {ok:true, msg:'Đã lưu can thiệp (ID: '+id+')'};
}

// ===== DỌN & ĐỊNH DẠNG SHEET THÔNG TIN THUỐC NGOẠI TRÚ (chạy tay 1 lần từ trình soạn thảo) =====
// Mở Apps Script -> chọn hàm dinhDangNgoaiTru -> bấm Run. Chạy 1 lần sẽ:
//  (1) xoá 3 cột thừa LoaiCanThiep / PhanLoaiCanThiep / KetQuaCanThiep (nếu còn)
//  (2) giãn rộng 400 + wrap text cho cột Nội dung chi tiết
// Thao tác trên FILE ngoại trú riêng, KHÔNG đụng file hiện tại.
function dinhDangNgoaiTru() {
  var sh = openSheetNgoaiTruRO_();
  if (!sh) return 'Chưa có file ngoại trú (hãy lưu 1 bản ghi ngoại trú trước).';

  // (1) Xoá 3 cột thừa — tìm theo tên, xoá từ phải sang trái để không lệch chỉ số
  var canXoa = ['LoaiCanThiep','PhanLoaiCanThiep','KetQuaCanThiep'];
  var hdr = sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0].map(function(x){return String(x).trim();});
  var viTri = [];
  canXoa.forEach(function(ten){ var i = hdr.indexOf(ten); if(i>=0) viTri.push(i+1); });
  viTri.sort(function(a,b){return b-a;}); // giảm dần
  viTri.forEach(function(col){ sh.deleteColumn(col); });

  // (2) Giãn rộng + wrap cột Nội dung chi tiết (đọc lại header sau khi xoá)
  var hdr2 = sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0].map(function(x){return String(x).trim();});
  var ndCol = hdr2.indexOf('NoiDungChiTiet') + 1;
  if (ndCol > 0) {
    sh.setColumnWidth(ndCol, 400);
    sh.getRange(1, ndCol, sh.getMaxRows(), 1).setWrap(true);
  }
  return 'Đã xoá ' + viTri.length + ' cột thừa + định dạng cột Nội dung chi tiết cho ' + SHEET_TTNGOAITRU;
}

// ===== LƯU HOẠT ĐỘNG =====
function luuHoatDong(form) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(SHEET_HOATDONG);
  if (!sheet) return {ok:false, msg:'Không tìm thấy sheet ' + SHEET_HOATDONG};

  if (!form.Ngay) return {ok:false, msg:'Vui lòng chọn Ngày'};
  if (!form.MaNS) return {ok:false, msg:'Vui lòng chọn Dược sĩ'};
  if (!form.LoaiCongViec) return {ok:false, msg:'Vui lòng chọn Loại công việc'};

  var id = Utilities.getUuid().substring(0, 7);
  var rowObj = {
    ID:id, MaNS:form.MaNS, Ngay:form.Ngay, Khoa:form.Khoa||'',
    BatDau:form.BatDau||'', ThoiGian:form.ThoiGian||'',
    LoaiCongViec:form.LoaiCongViec, ChiTietCongViec:form.ChiTietCongViec||''
  };
  appendByHeader(sheet, rowObj);
  return {ok:true, msg:'Đã lưu hoạt động (ID: '+id+')'};
}

// Ghi 1 dòng theo đúng header của sheet
function appendByHeader(sheet, rowObj) {
  var lastCol = sheet.getLastColumn();
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var row = [];
  for (var c = 0; c < headers.length; c++) {
    var h = String(headers[c]).trim();
    row.push(rowObj.hasOwnProperty(h) ? rowObj[h] : '');
  }
  sheet.appendRow(row);
}

// ===== BÁO CÁO THEO DƯỢC SĨ (lọc theo tháng) =====
// thang dạng "2026-08" hoặc '' = tất cả
function getBaoCao(thang) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();

  // map mã -> tên dược sĩ
  var dsMap = {}; var dsList = [];
  var dsSheet = ss.getSheetByName(SHEET_DUOCSI);
  var dsData = dsSheet.getDataRange().getValues();
  for (var i=1;i<dsData.length;i++){
    if(dsData[i][0]){
      var ma=String(dsData[i][0]).trim();
      dsMap[ma]=String(dsData[i][1]).trim();
      dsList.push(ma);
    }
  }

  // khởi tạo bộ đếm
  var stat = {};
  dsList.forEach(function(ma){
    stat[ma]={ten:dsMap[ma], ma:ma, canThiep:0, hoiChan:0, ttThuoc:0, tong:0, gioDiKhoa:0, soHuy:0};
  });

  // đếm từ CANTHIEP_DSLS
  var ct = ss.getSheetByName(SHEET_CANTHIEP);
  var ctData = ct.getDataRange().getValues();
  var ctH = ctData[0].map(function(x){return String(x).trim();});
  var iMaNS=ctH.indexOf('MaNS'), iNgay=ctH.indexOf('Ngay'), iLCV=ctH.indexOf('LoaiCongViec');
  for (var r=1;r<ctData.length;r++){
    var row=ctData[r];
    if(!row[iMaNS]) continue;
    if(thang && ymOf(row[iNgay])!==thang) continue;
    var lcv=String(row[iLCV]).trim();
    var maList=String(row[iMaNS]).split(',').map(function(s){return s.trim();}).filter(String);
    maList.forEach(function(ma){
      if(!stat[ma]) stat[ma]={ten:(dsMap[ma]||ma), ma:ma, canThiep:0, hoiChan:0, ttThuoc:0, tong:0, gioDiKhoa:0, soHuy:0};
      if(lcv==='Can thiệp DLS') stat[ma].canThiep++;
      else if(lcv==='Hội chẩn DLS') stat[ma].hoiChan++;
      else if(lcv==='Thông tin thuốc') stat[ma].ttThuoc++;
    });
  }

  // đếm thêm "Thông tin thuốc ngoại trú" từ sheet riêng TTTHUOC_NGOAITRU -> gộp vào cột TT thuốc
  var ttnt = openSheetNgoaiTruRO_();
  if(ttnt){
    var ntData = ttnt.getDataRange().getValues();
    if(ntData.length > 1){
      var ntH = ntData[0].map(function(x){return String(x).trim();});
      var nMaNS = ntH.indexOf('MaNS'), nNgay = ntH.indexOf('Ngay');
      for (var rr=1; rr<ntData.length; rr++){
        var nrow = ntData[rr];
        if(nMaNS<0 || !nrow[nMaNS]) continue;
        if(thang && ymOf(nrow[nNgay])!==thang) continue;
        var ntMaList = String(nrow[nMaNS]).split(',').map(function(s){return s.trim();}).filter(String);
        ntMaList.forEach(function(ma){
          if(!stat[ma]) stat[ma]={ten:(dsMap[ma]||ma), ma:ma, canThiep:0, hoiChan:0, ttThuoc:0, tong:0, gioDiKhoa:0, soHuy:0};
          stat[ma].ttThuoc++;
        });
      }
    }
  }

  // giờ đi khoa từ HOATDONG_DSLS (gộp mọi loại, trừ khoa Dược)
  var hd = ss.getSheetByName(SHEET_HOATDONG);
  if(hd){
    var hdData=hd.getDataRange().getValues();
    var hH=hdData[0].map(function(x){return String(x).trim();});
    var jMaNS=hH.indexOf('MaNS'), jNgay=hH.indexOf('Ngay'), jKhoa=hH.indexOf('Khoa'), jTG=hH.indexOf('ThoiGian');
    var jLCV=hH.indexOf('LoaiCongViec');
    for(var k=1;k<hdData.length;k++){
      var hr=hdData[k];
      if(!hr[jMaNS]) continue;
      if(thang && ymOf(hr[jNgay])!==thang) continue;
      if(String(hr[jKhoa]).trim()===KHOA_DUOC) continue;
      var gio=parseFloat(hr[jTG])||0;
      var maL=String(hr[jMaNS]).split(',').map(function(s){return s.trim();}).filter(String);
      maL.forEach(function(ma){
        if(!stat[ma]) stat[ma]={ten:(dsMap[ma]||ma), ma:ma, canThiep:0, hoiChan:0, ttThuoc:0, tong:0, gioDiKhoa:0, soHuy:0};
        stat[ma].gioDiKhoa += gio;
      });
      // Đếm số lần hủy thuốc: CHỈ tính cho dược sĩ đầu tiên trong danh sách
      if(jLCV>=0 && String(hr[jLCV]).trim()===LOAI_HUY_THUOC && maL.length>0){
        var maDau=maL[0];
        if(!stat[maDau]) stat[maDau]={ten:(dsMap[maDau]||maDau), ma:maDau, canThiep:0, hoiChan:0, ttThuoc:0, tong:0, gioDiKhoa:0, soHuy:0};
        stat[maDau].soHuy++;
      }
    }
  }

  // tính tổng + tỷ lệ đi khoa + tỷ lệ can thiệp
  var gioLam = tinhGioLamTheoThang(thang);
  var ngayLam = tinhNgayLamTheoThang(thang);
  var phuTrach = getPhuTrachMap();
  var soBN = {};
  if (thang) { var sb = getSoBNThang(thang); soBN = sb.soBN; }

  // Dữ liệu cho tỷ lệ DRP
  var drpCount = demDRPTheoThang(thang);
  var raDonCK = getRaDonCKMap();
  var soDon = {};
  if (thang) { var sd = getSoDonThang(thang); soDon = sd.soDon; }

  var out=[];
  Object.keys(stat).forEach(function(ma){
    var s=stat[ma];
    s.tong = s.canThiep + s.hoiChan + s.ttThuoc;
    s.gioDiKhoa = Math.round(s.gioDiKhoa*100)/100;
    s.gioLam = gioLam[ma] || 0;
    s.tyLe = (s.gioLam>0) ? Math.round(s.gioDiKhoa / s.gioLam * 1000)/10 : 0;

    // Tỷ lệ can thiệp
    var khoaList = phuTrach[ma] || [];
    var tongBNKhoa = 0;
    khoaList.forEach(function(k){ tongBNKhoa += (parseFloat(soBN[k])||0); });
    s.soNgayLam = ngayLam[ma] || 0;
    s.soLuotBN = tongBNKhoa * s.soNgayLam;
    s.tyLeCanThiep = (s.soLuotBN>0) ? Math.round(s.tong / s.soLuotBN * 1000)/10 : 0;

    // Tỷ lệ phát hiện DRP = số DRP / tổng số đơn các CK dược sĩ rà
    s.soDRP = drpCount[ma] || 0;
    var ckList = raDonCK[ma] || [];
    var tongDon = 0;
    ckList.forEach(function(ck){ tongDon += (parseFloat(soDon[ck])||0); });
    s.soDonRa = tongDon;
    s.tyLeDRP = (tongDon>0) ? Math.round(s.soDRP / tongDon * 1000)/10 : 0; // %

    out.push(s);
  });
  out.sort(function(a,b){return b.tong-a.tong;});
  return out;
}

// đổi giá trị ngày -> "YYYY-MM"
function ymOf(v){
  if(!v) return '';
  var d = (v instanceof Date) ? v : new Date(v);
  if(isNaN(d.getTime())) return '';
  var m=d.getMonth()+1;
  return d.getFullYear()+'-'+(m<10?'0':'')+m;
}

// ===== XUẤT EXCEL =====
// Tạo file Excel tạm trong Drive, trả về URL tải
function xuatExcel(thang){
  var data = getBaoCao(thang);
  // tạo spreadsheet tạm
  var tmp = SpreadsheetApp.create('BaoCao_DLS_'+(thang||'TatCa')+'_'+new Date().getTime());
  var sh = tmp.getActiveSheet();
  sh.appendRow(['Mã DS','Tên dược sĩ','Can thiệp','Hội chẩn','Thông tin thuốc','Tổng','Giờ đi khoa','Giờ làm việc','Tỷ lệ đi khoa (%)','Số lượt BN','Tỷ lệ can thiệp (%)','Số DRP','Số đơn rà','Tỷ lệ phát hiện DRP (%)','Số lần hủy thuốc']);
  data.forEach(function(s){
    sh.appendRow([s.ma, s.ten, s.canThiep, s.hoiChan, s.ttThuoc, s.tong, s.gioDiKhoa, s.gioLam, s.tyLe, s.soLuotBN, s.tyLeCanThiep, s.soDRP, s.soDonRa, s.tyLeDRP, (s.soHuy||0)]);
  });
  sh.getRange(1,1,1,15).setFontWeight('bold');
  SpreadsheetApp.flush();

  // export sang xlsx
  var id = tmp.getId();
  var url = 'https://docs.google.com/spreadsheets/d/'+id+'/export?format=xlsx';
  var token = ScriptApp.getOAuthToken();
  var blob = UrlFetchApp.fetch(url, {headers:{Authorization:'Bearer '+token}}).getBlob();
  blob.setName('BaoCao_DLS_'+(thang||'TatCa')+'.xlsx');
  var file = DriveApp.createFile(blob);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  // xoá spreadsheet tạm
  DriveApp.getFileById(id).setTrashed(true);
  return {ok:true, url:file.getDownloadUrl(), name:file.getName()};
}

// ===== GỢI Ý THUỐC ĐÃ NHẬP =====
// Trả về danh sách tên thuốc duy nhất đã từng nhập ở cột ThuocLienQuan
function getGoiYThuoc() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(SHEET_CANTHIEP);
  if (!sheet) return [];
  var data = sheet.getDataRange().getValues();
  if (data.length < 2) return [];
  var headers = data[0].map(function(x){return String(x).trim();});
  var idx = headers.indexOf('ThuocLienQuan');
  if (idx < 0) return [];
  var set = {};
  for (var i = 1; i < data.length; i++) {
    var v = String(data[i][idx] || '').trim();
    if (v) set[v] = true;
  }
  return Object.keys(set).sort();
}

// ===== GỢI Ý TÊN NHÂN VIÊN Y TẾ ĐÃ NHẬP =====
function getGoiYNVYT() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(SHEET_CANTHIEP);
  if (!sheet) return [];
  var data = sheet.getDataRange().getValues();
  if (data.length < 2) return [];
  var headers = data[0].map(function(x){return String(x).trim();});
  var idx = headers.indexOf('TenNVYT');
  if (idx < 0) return [];
  var set = {};
  for (var i = 1; i < data.length; i++) {
    var v = String(data[i][idx] || '').trim();
    if (v) set[v] = true;
  }
  return Object.keys(set).sort();
}

// ===== CHẤM CÔNG =====
var SHEET_CHAMCONG = 'CHAMCONG';   // sẽ tự tạo nếu chưa có
var GIO_CA_NGAY = 8;
var GIO_NUA_NGAY = 4;

// Tạo sheet CHAMCONG nếu chưa có (cột: Ngay | MaNS | TrangThai)
function ensureChamCongSheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_CHAMCONG);
  if (!sh) {
    sh = ss.insertSheet(SHEET_CHAMCONG);
    sh.appendRow(['Ngay','MaNS','TrangThai']);
  }
  return sh;
}

// Lấy dữ liệu chấm công của 1 tuần. monday = 'YYYY-MM-DD' (thứ 2 đầu tuần)
// Trả về: { days:[7 ngày], duocsi:[{ma,ten}], data:{ ma: { 'YYYY-MM-DD': 'Cả ngày'|'Nửa ngày'|'' } } }
function getChamCongTuan(monday) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  ensureChamCongSheet();

  // danh sách 9 dược sĩ
  var duocsi = [];
  var dsSheet = ss.getSheetByName(SHEET_DUOCSI);
  var dsData = dsSheet.getDataRange().getValues();
  for (var i=1;i<dsData.length;i++){ if(dsData[i][0]) duocsi.push({ma:String(dsData[i][0]).trim(), ten:String(dsData[i][1]).trim()}); }

  // 7 ngày trong tuần
  var days = [];
  var base = parseYMD(monday);
  for (var d=0; d<7; d++){
    var dt = new Date(base.getTime()); dt.setDate(base.getDate()+d);
    days.push(fmtYMD(dt));
  }

  // đọc dữ liệu chấm công đã lưu
  var cc = ss.getSheetByName(SHEET_CHAMCONG);
  var ccData = cc.getDataRange().getValues();
  var map = {}; // ma -> {ngay -> trangthai}
  for (var r=1;r<ccData.length;r++){
    var ngay = normNgay(ccData[r][0]);
    var ma = String(ccData[r][1]).trim();
    var tt = String(ccData[r][2]).trim();
    if(!ma || !ngay) continue;
    if(!map[ma]) map[ma]={};
    map[ma][ngay]=tt;
  }
  return {days:days, duocsi:duocsi, data:map};
}

// Lưu 1 ô chấm công (ghi đè nếu đã có ngày+mã đó)
function luuChamCong(ngay, ma, trangThai) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ensureChamCongSheet();
  var data = sh.getDataRange().getValues();
  ngay = String(ngay).trim();
  ma = String(ma).trim();
  var found = -1;
  // tìm dòng đã có (so khớp ngày đã chuẩn hoá)
  for (var r=1;r<data.length;r++){
    if (normNgay(data[r][0])===ngay && String(data[r][1]).trim()===ma) {
      if (found === -1) { found = r; }
      else {
        // dòng trùng thứ 2 trở đi -> xoá luôn để dọn sạch
        sh.deleteRow(r+1);
        // sau khi xoá, đọc lại data để index không lệch
        data = sh.getDataRange().getValues();
        r--;
      }
    }
  }
  if (found >= 0) {
    if (trangThai) {
      sh.getRange(found+1, 3).setValue(trangThai);
      sh.getRange(found+1, 1).setNumberFormat('@').setValue(ngay); // ép text
    } else {
      sh.deleteRow(found+1);
    }
    sapXepChamCong(sh);
    return {ok:true};
  }
  // chưa có -> thêm mới (nếu có trạng thái)
  if (trangThai) {
    sh.appendRow([ngay, ma, trangThai]);
    sh.getRange(sh.getLastRow(), 1).setNumberFormat('@').setValue(ngay); // ép text
    sapXepChamCong(sh);
  }
  return {ok:true};
}

// Sắp xếp sheet CHAMCONG theo Ngay tăng dần (rồi theo MaNS)
function sapXepChamCong(sh) {
  var last = sh.getLastRow();
  if (last < 3) return; // 0-1 dòng dữ liệu thì khỏi sắp
  sh.getRange(2, 1, last-1, 3).sort([{column:1, ascending:true},{column:2, ascending:true}]);
}

// Dọn toàn bộ dòng trùng trong CHAMCONG (giữ dòng CUỐI của mỗi cặp ngày+mã)
function donTrungChamCong() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ensureChamCongSheet();
  var data = sh.getDataRange().getValues();
  var seen = {}; // key -> row cuối cùng
  for (var r=1;r<data.length;r++){
    var key = normNgay(data[r][0]) + '||' + String(data[r][1]).trim();
    seen[key] = r; // ghi đè -> cuối cùng thắng
  }
  var keepRows = {};
  Object.keys(seen).forEach(function(k){ keepRows[seen[k]] = true; });
  // xoá từ dưới lên các dòng không giữ
  for (var r=data.length-1; r>=1; r--){
    if (!keepRows[r]) sh.deleteRow(r+1);
  }
  // ép cột Ngay về text
  var last = sh.getLastRow();
  if (last>1) {
    var rng = sh.getRange(2,1,last-1,1);
    var vals = rng.getValues();
    for (var i=0;i<vals.length;i++){ vals[i][0] = normNgay(vals[i][0]); }
    rng.setNumberFormat('@').setValues(vals);
  }
  sapXepChamCong(sh);
  return {ok:true, msg:'Đã dọn trùng + sắp xếp theo ngày. Còn '+(sh.getLastRow()-1)+' dòng.'};
}

// Tổng giờ làm việc theo tháng cho từng mã (T7/CN không tính)
function tinhGioLamTheoThang(thang) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  ensureChamCongSheet();
  var cc = ss.getSheetByName(SHEET_CHAMCONG);
  var data = cc.getDataRange().getValues();
  var gio = {}; // ma -> tổng giờ
  for (var r=1;r<data.length;r++){
    var ngay = normNgay(data[r][0]);
    var ma = String(data[r][1]).trim();
    var tt = String(data[r][2]).trim();
    if(!ma || !ngay) continue;
    if(thang && ngay.substring(0,7)!==thang) continue;
    var dt = parseYMD(ngay);
    var dow = dt.getDay(); // 0=CN, 6=T7
    if(dow===0 || dow===6) continue; // bỏ T7/CN
    var g = (tt==='Cả ngày') ? GIO_CA_NGAY : (tt==='Nửa ngày' ? GIO_NUA_NGAY : 0);
    gio[ma] = (gio[ma]||0) + g;
  }
  return gio;
}

// ===== Helpers ngày =====
function parseYMD(s){ var p=String(s).split('-'); return new Date(parseInt(p[0]),parseInt(p[1])-1,parseInt(p[2])); }
function fmtYMD(d){ var m=d.getMonth()+1, day=d.getDate(); return d.getFullYear()+'-'+(m<10?'0':'')+m+'-'+(day<10?'0':'')+day; }
function normNgay(v){
  if(v instanceof Date){
    // dùng timezone của spreadsheet để không lệch ngày
    var tz = tzNhanh_();
    return Utilities.formatDate(v, tz, 'yyyy-MM-dd');
  }
  var s=String(v).trim();
  // dd/mm/yyyy hoặc d/m/yyyy -> yyyy-MM-dd
  if(s.indexOf('/')>-1){
    var p=s.split('/');
    if(p.length===3){
      var dd=parseInt(p[0]), mm=parseInt(p[1]), yy=parseInt(p[2]);
      // nếu phần đầu > 12 chắc chắn là ngày (dd/mm); giữ quy ước dd/mm/yyyy
      return yy+'-'+(mm<10?'0':'')+mm+'-'+(dd<10?'0':'')+dd;
    }
  }
  // yyyy-mm-dd hoặc yyyy-m-d -> chuẩn hoá zero-pad
  if(s.indexOf('-')>-1){
    var q=s.split('-');
    if(q.length===3 && q[0].length===4){
      var Y=parseInt(q[0]), M=parseInt(q[1]), D=parseInt(q[2]);
      return Y+'-'+(M<10?'0':'')+M+'-'+(D<10?'0':'')+D;
    }
  }
  return s;
}

// ===== SỐ BN & PHỤ TRÁCH KLS =====
var SHEET_PHUTRACH = 'DM_PHUTRACH_KLS';   // cột: MaNS | Khoa
var SHEET_SOBN     = 'SO_BN_KHOA';        // cột: Thang | Khoa | SoBN (tự tạo)

function ensureSoBNSheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_SOBN);
  if (!sh) { sh = ss.insertSheet(SHEET_SOBN); sh.appendRow(['Thang','Khoa','SoBN']); }
  return sh;
}

// Danh sách khoa duy nhất trong DM_PHUTRACH_KLS (dùng cho màn Số BN)
function getKhoaLamSang() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_PHUTRACH);
  if (!sh) return [];
  var data = sh.getDataRange().getValues();
  var set = {};
  for (var i=1;i<data.length;i++){ var k=String(data[i][1]||'').trim(); if(k) set[k]=true; }
  return Object.keys(set).sort();
}

// Lấy số BN đã nhập cho 1 tháng -> { khoa: soBN }
function getSoBNThang(thang) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  ensureSoBNSheet();
  var sh = ss.getSheetByName(SHEET_SOBN);
  var data = sh.getDataRange().getValues();
  var out = {};
  for (var i=1;i<data.length;i++){
    if (normThang(data[i][0])===thang) out[String(data[i][1]).trim()] = data[i][2];
  }
  return { khoa: getKhoaLamSang(), soBN: out };
}

// Lưu số BN 1 tháng (nhận object {khoa: soBN}) - ghi đè
function luuSoBNThang(thang, soBNObj) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ensureSoBNSheet();
  var data = sh.getDataRange().getValues();
  // xoá các dòng cũ của tháng này (từ dưới lên)
  for (var r=data.length-1; r>=1; r--){
    if (normThang(data[r][0])===thang) sh.deleteRow(r+1);
  }
  // ghi lại (ép cột Thang dạng text để không bị đổi thành Date)
  Object.keys(soBNObj).forEach(function(khoa){
    var v = soBNObj[khoa];
    if (v!=='' && v!==null && !isNaN(parseFloat(v))) {
      sh.appendRow([thang, khoa, parseFloat(v)]);
      sh.getRange(sh.getLastRow(), 1).setNumberFormat('@').setValue(thang);
    }
  });
  return {ok:true, msg:'Đã lưu số BN tháng '+thang};
}

// Map dược sĩ -> danh sách khoa phụ trách
function getPhuTrachMap() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_PHUTRACH);
  var map = {};
  if (!sh) return map;
  var data = sh.getDataRange().getValues();
  for (var i=1;i<data.length;i++){
    var ma=String(data[i][0]||'').trim(), khoa=String(data[i][1]||'').trim();
    if(!ma||!khoa) continue;
    if(!map[ma]) map[ma]=[];
    map[ma].push(khoa);
  }
  return map;
}

// Số ngày đi làm theo tháng cho từng mã (cả ngày=1, nửa=0.5, bỏ T7/CN)
function tinhNgayLamTheoThang(thang) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  ensureChamCongSheet();
  var cc = ss.getSheetByName(SHEET_CHAMCONG);
  var data = cc.getDataRange().getValues();
  var ngay = {};
  for (var r=1;r<data.length;r++){
    var d = normNgay(data[r][0]);
    var ma = String(data[r][1]).trim();
    var tt = String(data[r][2]).trim();
    if(!ma||!d) continue;
    if(thang && d.substring(0,7)!==thang) continue;
    var dt = parseYMD(d), dow = dt.getDay();
    if(dow===0||dow===6) continue;
    var v = (tt==='Cả ngày')?1:(tt==='Nửa ngày'?0.5:0);
    ngay[ma] = (ngay[ma]||0) + v;
  }
  return ngay;
}

// ===== RÀ ĐƠN NGOẠI TRÚ =====
var SHEET_RADON = 'RADON_NGOAITRU';
var SHEET_CHUYENKHOA = 'DM_CHUYENKHOA';

// Danh sách chuyên khoa cho dropdown
function getChuyenKhoa() {
  return readOneCol(SpreadsheetApp.getActiveSpreadsheet(), SHEET_CHUYENKHOA, 0);
}

// Tạo sheet nếu chưa có
function ensureRaDonSheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_RADON);
  if (!sh) {
    sh = ss.insertSheet(SHEET_RADON);
    sh.appendRow(['ID','NgayKeDon','MaNS','ChuyenKhoa','TenBS','MaBN','LoaiDRP','ThuocLienQuan','NoiDungChiTiet','TLTK']);
  }
  return sh;
}

// Lưu 1 hoặc nhiều phiếu rà đơn (dán nhiều mã BN -> tách mỗi mã 1 dòng)
function luuRaDon(form) {
  var sh = ensureRaDonSheet();
  if (!form.MaBN) return {ok:false, msg:'Vui lòng nhập Mã bệnh nhân'};

  // Tách mã BN theo: xuống dòng, phẩy, chấm phẩy, hoặc khoảng trắng
  var maList = String(form.MaBN)
    .split(/[\n\r,;\s]+/)
    .map(function(s){return s.trim();})
    .filter(function(s){return s.length>0;});
  if (maList.length === 0) return {ok:false, msg:'Vui lòng nhập Mã bệnh nhân'};

  var count = 0;
  maList.forEach(function(maBN){
    var id = Utilities.getUuid().substring(0,7);
    var rowObj = {
      ID:id, NgayKeDon:form.NgayKeDon||'', MaNS:form.MaNS||'',
      ChuyenKhoa:form.ChuyenKhoa||'', TenBS:form.TenBS||'', MaBN:maBN,
      LoaiDRP:form.LoaiDRP||'', ThuocLienQuan:form.ThuocLienQuan||'',
      NoiDungChiTiet:form.NoiDungChiTiet||'', TLTK:form.TLTK||''
    };
    appendByHeader(sh, rowObj);
    count++;
  });

  var msg = (count===1) ? 'Đã lưu 1 phiếu rà đơn' : ('Đã lưu '+count+' phiếu (mỗi mã BN 1 dòng)');
  return {ok:true, msg:msg};
}

// Gợi ý thuốc từ cả 2 sheet (can thiệp + rà đơn)
function getGoiYThuocRaDon() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var set = {};
  [SHEET_RADON, SHEET_CANTHIEP].forEach(function(name){
    var sh = ss.getSheetByName(name);
    if (!sh) return;
    var data = sh.getDataRange().getValues();
    if (data.length < 2) return;
    var headers = data[0].map(function(x){return String(x).trim();});
    var idx = headers.indexOf('ThuocLienQuan');
    if (idx < 0) return;
    for (var i=1;i<data.length;i++){ var v=String(data[i][idx]||'').trim(); if(v) set[v]=true; }
  });
  return Object.keys(set).sort();
}

// ===== SỐ ĐƠN NGOẠI TRÚ & TỶ LỆ DRP =====
var SHEET_RADON_CK = 'DM_RADON_CK';      // cột: MaNS | ChuyenKhoa (dược sĩ rà CK nào)
var SHEET_SODON    = 'SO_DON_NGOAITRU';  // cột: Thang | ChuyenKhoa | SoDon (tự tạo)

function ensureSoDonSheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_SODON);
  if (!sh) { sh = ss.insertSheet(SHEET_SODON); sh.appendRow(['Thang','ChuyenKhoa','SoDon']); }
  return sh;
}

// Danh sách chuyên khoa duy nhất trong DM_RADON_CK (cho màn Số đơn)
function getChuyenKhoaRaDon() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_RADON_CK);
  if (!sh) return [];
  var data = sh.getDataRange().getValues();
  var set = {};
  for (var i=1;i<data.length;i++){ var k=String(data[i][1]||'').trim(); if(k) set[k]=true; }
  return Object.keys(set).sort();
}

// Lấy số đơn đã nhập cho 1 tháng
function getSoDonThang(thang) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  ensureSoDonSheet();
  var sh = ss.getSheetByName(SHEET_SODON);
  var data = sh.getDataRange().getValues();
  var out = {};
  for (var i=1;i<data.length;i++){
    if (normThang(data[i][0])===thang) out[String(data[i][1]).trim()] = data[i][2];
  }
  return { chuyenKhoa: getChuyenKhoaRaDon(), soDon: out };
}

// Lưu số đơn 1 tháng (ghi đè)
function luuSoDonThang(thang, obj) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ensureSoDonSheet();
  var data = sh.getDataRange().getValues();
  for (var r=data.length-1; r>=1; r--){ if (normThang(data[r][0])===thang) sh.deleteRow(r+1); }
  Object.keys(obj).forEach(function(ck){
    var v = obj[ck];
    if (v!=='' && v!==null && !isNaN(parseFloat(v))) {
      sh.appendRow([thang, ck, parseFloat(v)]);
      sh.getRange(sh.getLastRow(), 1).setNumberFormat('@').setValue(thang);
    }
  });
  return {ok:true, msg:'Đã lưu số đơn tháng '+thang};
}

// Map dược sĩ -> danh sách chuyên khoa rà
function getRaDonCKMap() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_RADON_CK);
  var map = {};
  if (!sh) return map;
  var data = sh.getDataRange().getValues();
  for (var i=1;i<data.length;i++){
    var ma=String(data[i][0]||'').trim(), ck=String(data[i][1]||'').trim();
    if(!ma||!ck) continue;
    if(!map[ma]) map[ma]=[];
    map[ma].push(ck);
  }
  return map;
}

// Đếm số DRP (số phiếu rà đơn) theo dược sĩ, lọc theo tháng của NgayKeDon
function demDRPTheoThang(thang) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_RADON);
  var out = {};
  if (!sh) return out;
  var data = sh.getDataRange().getValues();
  if (data.length < 2) return out;
  var H = data[0].map(function(x){return String(x).trim();});
  var iMaNS=H.indexOf('MaNS'), iNgay=H.indexOf('NgayKeDon');
  for (var r=1;r<data.length;r++){
    var ma=String(data[r][iMaNS]||'').trim();
    if(!ma) continue;
    if(thang && ymOf(data[r][iNgay])!==thang) continue;
    out[ma] = (out[ma]||0) + 1;
  }
  return out;
}

// Chuẩn hóa giá trị tháng về "YYYY-MM" (xử lý cả Date lẫn text "2026-08", "2026-08-01", "8/2026"...)
function normThang(v){
  if (v instanceof Date){
    var tz = tzNhanh_();
    return Utilities.formatDate(v, tz, 'yyyy-MM');
  }
  var s = String(v).trim();
  // "2026-08" hoặc "2026-08-01" -> lấy 7 ký tự đầu nếu đúng dạng
  if (/^\d{4}-\d{1,2}/.test(s)){
    var p = s.split('-');
    var Y = p[0], M = parseInt(p[1]);
    return Y + '-' + (M<10?'0':'') + M;
  }
  // "8/2026" hoặc "08/2026"
  if (/^\d{1,2}\/\d{4}$/.test(s)){
    var q = s.split('/');
    var mm = parseInt(q[0]);
    return q[1] + '-' + (mm<10?'0':'') + mm;
  }
  return s;
}

// Dọn trùng + ép cột Thang về text cho SO_BN_KHOA và SO_DON_NGOAITRU (chạy 1 lần)
function donSoBN_SoDon() {
  var kq = [];
  kq.push(donSheetThang(SHEET_SOBN));
  kq.push(donSheetThang(SHEET_SODON));
  var msg = kq.join(' | ');
  Logger.log(msg);
  return {ok:true, msg:msg};
}

// Dọn 1 sheet dạng (Thang | Key | So): giữ dòng CUỐI của mỗi cặp Thang+Key, ép Thang text
function donSheetThang(sheetName) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(sheetName);
  if (!sh) return sheetName + ': không có';
  var data = sh.getDataRange().getValues();
  if (data.length < 2) return sheetName + ': trống';
  var seen = {}; // key -> row cuối cùng (giá trị mới nhất thắng)
  for (var r=1;r<data.length;r++){
    var key = normThang(data[r][0]) + '||' + String(data[r][1]).trim();
    seen[key] = r;
  }
  var keep = {};
  Object.keys(seen).forEach(function(k){ keep[seen[k]] = true; });
  // xoá từ dưới lên các dòng không giữ
  for (var r=data.length-1; r>=1; r--){ if (!keep[r]) sh.deleteRow(r+1); }
  // ép cột Thang (cột A) về text chuẩn hoá
  var last = sh.getLastRow();
  if (last>1){
    var rng = sh.getRange(2,1,last-1,1);
    var vals = rng.getValues();
    for (var i=0;i<vals.length;i++){ vals[i][0] = normThang(vals[i][0]); }
    rng.setNumberFormat('@').setValues(vals);
  }
  return sheetName + ': còn ' + (sh.getLastRow()-1) + ' dòng';
}
