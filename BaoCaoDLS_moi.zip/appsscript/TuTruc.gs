/**
 * ============================================================
 *  BẢNG KIỂM TỦ TRỰC  —  Phụ lục 02
 *  File riêng, nằm chung dự án với app báo cáo DLS.
 *  Mọi hàm có tiền tố tt_ nên không trùng tên hàm cũ.
 *  Code cũ chỉ phải sửa 2 chỗ, mỗi chỗ 1 dòng (xem HUONG_DAN_CAI_DAT.md).
 * ============================================================
 */

// ===== CẤU HÌNH =====
var TT_SHEET_TIEUCHI = 'DM_TIEUCHI_TUTRUC';
var TT_SHEET_PHIEU   = 'TUTRUC_PHIEU';
var TT_SHEET_CHITIET = 'TUTRUC_CHITIET';
var TT_SHEET_KHOA    = 'DM_KHOA';
var TT_SHEET_DUOCSI  = 'DM_DUOCSI';

var TT_THU_MUC_GOC   = 'Bang kiem tu truc';   // thư mục ảnh trên Drive

// --- Kích thước ảnh minh chứng trong file PDF ---
// TT_ANH_ROI_HANG = false : ảnh nằm bên phải phần chữ (giống phiếu mẫu)
//                 = true  : ảnh xuống dòng dưới phần chữ, to hơn nhiều
var TT_ANH_ROI_HANG = false;
var TT_SO_ANH_TOI_DA = 0;    // số ảnh tối đa in ra cho MỖI tiêu chí. 0 = in hết.
var TT_RONG_ANH     = 290;   // chiều rộng ảnh, tính bằng điểm.
                             // Nằm cạnh chữ: tối đa khoảng 320.
                             // Xuống dòng riêng: tăng được tới khoảng 470.

var TT_DAT     = 'ĐẠT';
var TT_KHONG   = 'KHÔNG ĐẠT';
var TT_KAD     = 'KHÔNG ĐÁNH GIÁ ĐƯỢC';
var TT_KAD_CU  = 'KHÔNG ÁP DỤNG';   // nhãn cũ, giữ để phiếu đã lưu vẫn đọc được

// Tên người ký trên báo cáo tổng hợp — sửa trực tiếp tại đây
var TT_NGUOI_TONG_HOP   = 'Hà Ngọc Minh';
var TT_TRUONG_KHOA_DUOC = 'Nguyễn Quỳnh Hoa';

var TT_COLS_PHIEU = ['ma_phieu','ngay_kiem','thang','khoa',
  'ma_nguoi_giam_sat','nguoi_giam_sat','dieu_duong','truong_khoa','truong_khoa_duoc',
  'gio_bat_dau','gio_ket_thuc',
  'so_dat','so_khong_dat','so_khong_ap_dung','ty_le_dat',
  'nhan_xet','de_nghi','trang_thai','nguoi_nhap','thoi_diem_nhap',
  'ky_giam_sat','ky_dieu_duong','ky_truong_khoa','ky_truong_khoa_duoc'];

var TT_COLS_CHITIET = ['ma_phieu','ma_tc','ket_qua','ghi_chu','anh_ids'];

// ===== TIỆN ÍCH CHUNG =====
function tt_ss() { return SpreadsheetApp.getActiveSpreadsheet(); }
function tt_tz() { return tzNhanh_(); }

/** Chuẩn hoá ngày về chuỗi yyyy-MM-dd theo múi giờ của Sheet.
 *  Dùng lại đúng cách xử lý đã sửa lỗi lệch ngày ở màn Chấm công. */
function tt_ngayChuoi(v) {
  if (v === '' || v == null) return '';
  if (Object.prototype.toString.call(v) === '[object Date]') {
    return Utilities.formatDate(v, tt_tz(), 'yyyy-MM-dd');
  }
  var s = String(v).trim();
  var m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);   // dd/MM/yyyy
  if (m) return m[3] + '-' + ('0' + m[2]).slice(-2) + '-' + ('0' + m[1]).slice(-2);
  return s.slice(0, 10);
}

/** Tháng (yyyy-MM) của 1 dòng phiếu. LUÔN suy ra từ ngay_kiem.
 *  Không tin cột thang, vì Google Sheets có thể tự đổi '2026-08' thành kiểu Ngày. */
function tt_thangCua(r) {
  var ng = tt_ngayChuoi(r['ngay_kiem']);
  if (ng && ng.length >= 7) return ng.slice(0, 7);
  return tt_ngayChuoi(r['thang']).slice(0, 7);
}

/** Lấy sheet, tự tạo kèm header nếu chưa có. */
function tt_laySheet(ten, cols) {
  var ss = tt_ss();
  var sh = ss.getSheetByName(ten);
  if (!sh) {
    sh = ss.insertSheet(ten);
    sh.getRange(1, 1, 1, cols.length).setValues([cols]).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  return sh;
}

/** Đọc cả sheet thành mảng object, key = tên cột ở dòng 1. */
function tt_docBang(ten) {
  var sh = tt_ss().getSheetByName(ten);
  if (!sh) return [];
  var v = sh.getDataRange().getValues();
  if (v.length < 2) return [];
  var h = v[0].map(function (x) { return String(x).trim(); });
  var out = [];
  for (var i = 1; i < v.length; i++) {
    if (v[i].join('').trim() === '') continue;
    var o = {};
    for (var j = 0; j < h.length; j++) o[h[j]] = v[i][j];
    out.push(o);
  }
  return out;
}

/** Lấy giá trị theo danh sách tên cột ứng viên (không phân biệt hoa/thường, khoảng trắng).
 *  Nhờ vậy code chạy được dù DM_KHOA / DM_DUOCSI đặt tên cột hơi khác nhau. */
function tt_giaTri(obj, ungVien) {
  var chuan = function (s) { return String(s).toLowerCase().replace(/[\s_]+/g, ''); };
  var keys = Object.keys(obj);
  for (var i = 0; i < ungVien.length; i++) {
    for (var j = 0; j < keys.length; j++) {
      if (chuan(keys[j]) === chuan(ungVien[i])) {
        var val = obj[keys[j]];
        if (val !== '' && val != null) return String(val).trim();
      }
    }
  }
  return '';
}

function tt_laBool(v) {
  var s = String(v).trim().toLowerCase();
  return s === 'true' || s === 'x' || s === '1' || s === 'có' || s === 'co';
}

// ===== KHỞI TẠO =====
/** Chạy 1 lần sau khi dán code. Tạo 2 sheet dữ liệu nếu chưa có. */
function tt_khoiTao() {
  tt_laySheet(TT_SHEET_PHIEU, TT_COLS_PHIEU);
  tt_laySheet(TT_SHEET_CHITIET, TT_COLS_CHITIET);
  tt_epCotVanBan();

  var thieu = [];
  if (!tt_ss().getSheetByName(TT_SHEET_TIEUCHI)) thieu.push(TT_SHEET_TIEUCHI);
  if (!tt_ss().getSheetByName(TT_SHEET_KHOA))    thieu.push(TT_SHEET_KHOA);
  if (!tt_ss().getSheetByName(TT_SHEET_DUOCSI))  thieu.push(TT_SHEET_DUOCSI);

  var tb = 'Đã tạo xong TUTRUC_PHIEU và TUTRUC_CHITIET.';
  if (thieu.length) tb += '\n\nCHƯA THẤY các sheet: ' + thieu.join(', ');
  Logger.log(tb);
  return tb;
}

// ===== DANH MỤC CHO FORM =====
function tt_layDanhMuc() {
  var tieuChi = tt_docBang(TT_SHEET_TIEUCHI).map(function (r) {
    return {
      maTc:     Number(tt_giaTri(r, ['ma_tc'])),
      nhom:     tt_giaTri(r, ['nhom']),
      tenNhom:  tt_giaTri(r, ['ten_nhom']),
      noiDung:  tt_giaTri(r, ['noi_dung']),
      coSao:    tt_laBool(r['co_sao']),
      choKad:   tt_laBool(r['cho_phep_khong_ap_dung']),
      ghiChuTc: tt_giaTri(r, ['ghi_chu_tc']),
      huongDan: tt_giaTri(r, ['huong_dan'])
    };
  }).filter(function (t) { return t.maTc > 0; })
    .sort(function (a, b) { return a.maTc - b.maTc; });

  var khoa = [];
  tt_docBang(TT_SHEET_KHOA).forEach(function (r) {
    var t = tt_giaTri(r, ['TenKhoa', 'Khoa', 'ten_khoa', 'Ten', 'TenDonVi', 'Name']);
    if (t && khoa.indexOf(t) < 0) khoa.push(t);
  });

  var duocSi = tt_docBang(TT_SHEET_DUOCSI).map(function (r) {
    return {
      ma:  tt_giaTri(r, ['MaNS', 'Ma', 'MaDS', 'ma_ns', 'ID', 'Code']),
      ten: tt_giaTri(r, ['TenDS', 'Ten', 'TenDuocSi', 'HoTen', 'ten_ds', 'Name'])
    };
  }).filter(function (d) { return d.ten; });

  return { tieuChi: tieuChi, khoa: khoa, duocSi: duocSi };
}

// ===== MÃ PHIẾU =====
function tt_taoMaPhieu() {
  return 'TT-' + Utilities.formatDate(new Date(), tt_tz(), 'yyyyMMdd-HHmmss');
}

// ===== ẢNH MINH CHỨNG =====
function tt_timHoacTao(cha, ten) {
  var it = cha.getFoldersByName(ten);
  return it.hasNext() ? it.next() : cha.createFolder(ten);
}

function tt_thuMuc(maPhieu) {
  var thang = maPhieu.slice(3, 9);                       // yyyyMM
  thang = thang.slice(0, 4) + '-' + thang.slice(4, 6);   // yyyy-MM
  var goc = tt_timHoacTao(DriveApp.getRootFolder(), TT_THU_MUC_GOC);
  return tt_timHoacTao(tt_timHoacTao(goc, thang), maPhieu);
}

/** Nhận 1 ảnh đã nén từ trình duyệt, lưu Drive, trả về id + link xem.
 *  Tải từng ảnh ngay lúc chọn để không dồn dữ liệu nặng vào lúc bấm Lưu. */
function tt_taiAnh(maPhieu, anh) {
  if (!maPhieu) throw new Error('Thiếu mã phiếu.');
  var blob = Utilities.newBlob(Utilities.base64Decode(anh.data), anh.mime, anh.ten);
  var f = tt_thuMuc(maPhieu).createFile(blob);
  return { id: f.getId(), url: 'https://drive.google.com/thumbnail?id=' + f.getId() + '&sz=w400' };
}

function tt_xoaAnh(id) {
  try { DriveApp.getFileById(id).setTrashed(true); } catch (e) {}
  return true;
}

// ===== LƯU PHIẾU =====
/**
 * p = {
 *   maPhieu, ngay, khoa, maDuocSi, nguoiGiamSat, dieuDuong,
 *   truongKhoa, truongKhoaDuoc, gioBatDau, gioKetThuc,
 *   nhanXet, deNghi, trangThai,
 *   chiTiet: [{ maTc, ketQua, ghiChu, anhIds:[] }]
 * }
 */
function tt_luuPhieu(p) {
  var lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    if (!p.maPhieu) throw new Error('Thiếu mã phiếu.');
    if (!p.khoa)    throw new Error('Chưa chọn Khoa/Trung tâm.');
    if (!p.ngay)    throw new Error('Chưa chọn ngày kiểm tra.');
    if (!p.nguoiGiamSat) throw new Error('Chưa chọn người giám sát.');

    var dsTieuChi = tt_layDanhMuc().tieuChi;
    var choKad = {};
    dsTieuChi.forEach(function (t) { choKad[t.maTc] = t.choKad; });

    var ct = p.chiTiet || [];
    if (ct.length !== dsTieuChi.length) {
      throw new Error('Còn tiêu chí chưa chấm (' + ct.length + '/' + dsTieuChi.length + ').');
    }

    // Kiểm tra từng tiêu chí — đây là chốt chặn thật, phía trình duyệt chỉ là nhắc trước.
    var soDat = 0, soKhong = 0, soKad = 0;
    ct.forEach(function (c) {
      var kq = String(c.ketQua || '').trim();
      if ([TT_DAT, TT_KHONG, TT_KAD, TT_KAD_CU].indexOf(kq) < 0) {
        throw new Error('Tiêu chí ' + c.maTc + ' chưa được chấm.');
      }
      if ((kq === TT_KAD || kq === TT_KAD_CU) && !choKad[c.maTc]) {
        throw new Error('Tiêu chí ' + c.maTc + ' không được phép chọn Không áp dụng.');
      }
      if (kq !== TT_DAT && !String(c.ghiChu || '').trim()) {
        throw new Error('Tiêu chí ' + c.maTc + ': ' +
          (kq === TT_KAD ? 'phải ghi lý do không áp dụng.' : 'phải ghi nội dung chưa đạt.'));
      }
      if (kq === TT_DAT) soDat++;
      else if (kq === TT_KHONG) soKhong++;
      else soKad++;
    });

    var mauSo = soDat + soKhong;
    var tyLe = mauSo > 0 ? Math.round(soDat / mauSo * 1000) / 10 : '';

    var ngay = tt_ngayChuoi(p.ngay);
    var dong = {
      ma_phieu: p.maPhieu,
      ngay_kiem: ngay,
      thang: ngay.slice(0, 7),
      khoa: p.khoa,
      ma_nguoi_giam_sat: p.maDuocSi || '',
      nguoi_giam_sat: p.nguoiGiamSat || '',
      dieu_duong: p.dieuDuong || '',
      truong_khoa: p.truongKhoa || '',
      truong_khoa_duoc: p.truongKhoaDuoc || '',
      gio_bat_dau: p.gioBatDau || '',
      gio_ket_thuc: p.gioKetThuc || '',
      so_dat: soDat,
      so_khong_dat: soKhong,
      so_khong_ap_dung: soKad,
      ty_le_dat: tyLe,
      nhan_xet: p.nhanXet || '',
      de_nghi: p.deNghi || '',
      trang_thai: p.trangThai || 'Hoàn thành',
      nguoi_nhap: Session.getActiveUser().getEmail(),
      thoi_diem_nhap: Utilities.formatDate(new Date(), tt_tz(), 'yyyy-MM-dd HH:mm:ss'),
      ky_giam_sat: '', ky_dieu_duong: '', ky_truong_khoa: '', ky_truong_khoa_duoc: ''
    };

    tt_xoaPhieuCu(p.maPhieu);   // lưu lại phiếu cũ thì ghi đè, không sinh dòng trùng

    var shP = tt_laySheet(TT_SHEET_PHIEU, TT_COLS_PHIEU);
    shP.appendRow(TT_COLS_PHIEU.map(function (c) { return dong[c]; }));

    var shC = tt_laySheet(TT_SHEET_CHITIET, TT_COLS_CHITIET);
    var rows = ct.sort(function (a, b) { return a.maTc - b.maTc; }).map(function (c) {
      return [p.maPhieu, c.maTc, c.ketQua, c.ghiChu || '', (c.anhIds || []).join(',')];
    });
    if (rows.length) {
      shC.getRange(shC.getLastRow() + 1, 1, rows.length, TT_COLS_CHITIET.length).setValues(rows);
    }

    return { ok: true, maPhieu: p.maPhieu, soDat: soDat, soKhong: soKhong, soKad: soKad, tyLe: tyLe };
  } finally {
    lock.releaseLock();
  }
}

function tt_xoaPhieuCu(maPhieu) {
  [[TT_SHEET_PHIEU, TT_COLS_PHIEU], [TT_SHEET_CHITIET, TT_COLS_CHITIET]].forEach(function (x) {
    var sh = tt_ss().getSheetByName(x[0]);
    if (!sh || sh.getLastRow() < 2) return;
    var col = sh.getRange(2, 1, sh.getLastRow() - 1, 1).getValues();
    for (var i = col.length - 1; i >= 0; i--) {
      if (String(col[i][0]).trim() === maPhieu) sh.deleteRow(i + 2);
    }
  });
}

// ===== ĐỌC LẠI PHIẾU (để sửa) =====
function tt_layPhieu(maPhieu) {
  var phieu = null;
  tt_docBang(TT_SHEET_PHIEU).forEach(function (r) {
    if (String(r['ma_phieu']).trim() === maPhieu) phieu = r;
  });
  if (!phieu) return null;
  phieu['ngay_kiem'] = tt_ngayChuoi(phieu['ngay_kiem']);

  var ct = tt_docBang(TT_SHEET_CHITIET)
    .filter(function (r) { return String(r['ma_phieu']).trim() === maPhieu; })
    .map(function (r) {
      var ids = String(r['anh_ids'] || '').split(',')
        .map(function (s) { return s.trim(); })
        .filter(function (s) { return s; });
      return {
        maTc: Number(r['ma_tc']),
        ketQua: String(r['ket_qua'] || '').trim(),
        ghiChu: String(r['ghi_chu'] || ''),
        anhIds: ids,
        anhUrls: ids.map(function (id) {
          return 'https://drive.google.com/thumbnail?id=' + id.trim() + '&sz=w400';
        })
      };
    });

  return { phieu: phieu, chiTiet: ct };
}

/** Danh sách phiếu của 1 tháng (yyyy-MM). Bỏ trống = tất cả. */
function tt_danhSachPhieu(thang) {
  return tt_docBang(TT_SHEET_PHIEU)
    .filter(function (r) { return !thang || tt_thangCua(r) === thang; })
    .map(function (r) {
      return {
        maPhieu: r['ma_phieu'],
        ngay: tt_ngayChuoi(r['ngay_kiem']),
        khoa: r['khoa'],
        nguoiGiamSat: r['nguoi_giam_sat'],
        soDat: r['so_dat'],
        soKhong: r['so_khong_dat'],
        soKad: r['so_khong_ap_dung'],
        tyLe: r['ty_le_dat'],
        trangThai: r['trang_thai']
      };
    })
    .sort(function (a, b) { return a.ngay < b.ngay ? 1 : -1; });
}

// ============================================================
//  PHẦN 2 — BÁO CÁO TỔNG HỢP VÀ XUẤT PDF
// ============================================================

/** Gom dữ liệu báo cáo của 1 tháng (yyyy-MM). Bỏ trống = tất cả. */
function tt_duLieuBaoCao(thang) {
  var tieuChi = tt_layDanhMuc().tieuChi;
  var tenTc = {};
  tieuChi.forEach(function (t) { tenTc[t.maTc] = t.noiDung; });

  var phieu = tt_docBang(TT_SHEET_PHIEU).filter(function (r) {
    return !thang || tt_thangCua(r) === thang;
  });
  var maList = phieu.map(function (r) { return String(r['ma_phieu']).trim(); });

  var theoPhieu = {};
  tt_docBang(TT_SHEET_CHITIET).forEach(function (r) {
    var ma = String(r['ma_phieu']).trim();
    if (maList.indexOf(ma) < 0) return;
    if (!theoPhieu[ma]) theoPhieu[ma] = [];
    theoPhieu[ma].push({
      maTc: Number(r['ma_tc']),
      ketQua: String(r['ket_qua'] || '').trim(),
      ghiChu: String(r['ghi_chu'] || ''),
      anhIds: String(r['anh_ids'] || '').split(',').map(function (s) { return s.trim(); })
                .filter(function (s) { return s; })
    });
  });

  var tongHop = [], chiTiet = [], demTc = {}, khoaTc = {};
  var tongTyLe = 0, demTyLe = 0;

  phieu.forEach(function (r) {
    var ma = String(r['ma_phieu']).trim();
    var khoa = String(r['khoa'] || '');
    var ngay = tt_ngayChuoi(r['ngay_kiem']);
    var ds = (theoPhieu[ma] || []).sort(function (a, b) { return a.maTc - b.maTc; });

    var tyLe = r['ty_le_dat'];
    if (tyLe !== '' && tyLe != null) { tongTyLe += Number(tyLe); demTyLe++; }

    tongHop.push({
      maPhieu: ma, khoa: khoa, ngay: ngay,
      nguoiGiamSat: String(r['nguoi_giam_sat'] || ''),
      soDat: Number(r['so_dat'] || 0),
      soKhong: Number(r['so_khong_dat'] || 0),
      soKad: Number(r['so_khong_ap_dung'] || 0),
      tyLe: tyLe === '' || tyLe == null ? '' : Number(tyLe),
      nhanXet: String(r['nhan_xet'] || ''),
      deNghi: String(r['de_nghi'] || '')
    });

    var loi = ds.filter(function (c) { return c.ketQua === TT_KHONG; }).map(function (c) {
      if (!demTc[c.maTc]) { demTc[c.maTc] = 0; khoaTc[c.maTc] = []; }
      demTc[c.maTc]++;
      if (khoaTc[c.maTc].indexOf(khoa) < 0) khoaTc[c.maTc].push(khoa);
      return { maTc: c.maTc, noiDung: tenTc[c.maTc] || '', ghiChu: c.ghiChu, anhIds: c.anhIds };
    });
    var kad = ds.filter(function (c) {
      return c.ketQua === TT_KAD || c.ketQua === TT_KAD_CU;
    }).map(function (c) {
      return { maTc: c.maTc, noiDung: tenTc[c.maTc] || '', ghiChu: c.ghiChu };
    });

    if (loi.length || kad.length) {
      chiTiet.push({ maPhieu: ma, khoa: khoa, ngay: ngay, loi: loi, kad: kad });
    }
  });

  tongHop.sort(function (a, b) {
    var x = a.tyLe === '' ? 999 : a.tyLe, y = b.tyLe === '' ? 999 : b.tyLe;
    return x - y;
  });

  var tanSuat = Object.keys(demTc).map(function (k) {
    return { maTc: Number(k), noiDung: tenTc[k] || '', soKhoa: demTc[k], dsKhoa: khoaTc[k] };
  }).sort(function (a, b) { return b.soKhoa - a.soKhoa || a.maTc - b.maTc; });

  return {
    thang: thang || '',
    tongHop: tongHop,
    tanSuat: tanSuat,
    chiTiet: chiTiet,
    tong: {
      soPhieu: phieu.length,
      soKhoa: tongHop.map(function (x) { return x.khoa; })
                .filter(function (v, i, a) { return a.indexOf(v) === i; }).length,
      tbTyLe: demTyLe ? Math.round(tongTyLe / demTyLe * 10) / 10 : ''
    }
  };
}

// ===== TIỆN ÍCH DỰNG TÀI LIỆU =====
function tt_dongTieuDe(body, text, cỡ, giua) {
  var p = body.appendParagraph(text);
  p.setAttributes({
    FONT_FAMILY: 'Arial', FONT_SIZE: cỡ, BOLD: true,
    SPACING_BEFORE: 6, SPACING_AFTER: 4
  });
  if (giua) p.setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  return p;
}

function tt_dongThuong(body, text, cỡ, giua) {
  var p = body.appendParagraph(text);
  p.setAttributes({ FONT_FAMILY: 'Arial', FONT_SIZE: cỡ || 10, BOLD: false,
                    SPACING_BEFORE: 0, SPACING_AFTER: 2 });
  if (giua) p.setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  return p;
}

function tt_dinhDangBang(bang, rongCot, cỡ) {
  bang.setBorderWidth(0.5);
  if (rongCot) rongCot.forEach(function (w, i) { try { bang.setColumnWidth(i, w); } catch (e) {} });
  for (var r = 0; r < bang.getNumRows(); r++) {
    var row = bang.getRow(r);
    for (var c = 0; c < row.getNumCells(); c++) {
      var cell = row.getCell(c);
      cell.setPaddingTop(3).setPaddingBottom(3).setPaddingLeft(4).setPaddingRight(4);
      cell.editAsText().setAttributes({ FONT_FAMILY: 'Arial', FONT_SIZE: cỡ || 9, BOLD: r === 0 });
      if (r === 0) cell.setBackgroundColor('#e6f1fb');
    }
  }
}

/** Ghi 1 đoạn vào ô bảng. Lần đầu dùng lại đoạn trống sẵn có sau clear(),
 *  tránh để lại dòng trắng thừa phía trên. */
function tt_doanO(cell, text, dam, co) {
  var noiDung = (text == null) ? '' : String(text);
  var p = null;

  // Dùng lại đoạn trống sẵn có sau clear(), nhưng chỉ khi nó thật sự rỗng
  // (getText() rỗng VÀ chưa chứa phần tử con nào, ví dụ ảnh đã chèn trước đó).
  if (cell.getNumChildren() > 0) {
    var e = cell.getChild(0);
    if (e.getType() === DocumentApp.ElementType.PARAGRAPH) {
      var pr = e.asParagraph();
      if (pr.getText() === '' && pr.getNumChildren() === 0) {
        p = pr;
        // setText() trả về void — KHÔNG gán lại p, nếu không sẽ sinh đoạn trùng.
        // Chuỗi rỗng thì bỏ qua, vì setText('') bị Apps Script chặn.
        if (noiDung !== '') p.setText(noiDung);
      }
    }
  }

  // appendParagraph('') cũng bị chặn, nên thay bằng một dấu cách.
  if (!p) p = cell.appendParagraph(noiDung !== '' ? noiDung : ' ');

  // setAttributes lên đoạn RỖNG cũng bị ném "Cannot insert an empty text element"
  if (noiDung !== '') {
    p.setAttributes({ FONT_FAMILY: 'Arial', FONT_SIZE: co || 9, BOLD: !!dam });
  }
  return p;
}

/** Lấy một đoạn văn trống trong ô để chèn ảnh vào.
 *  Không đặt thuộc tính gì, vì đoạn rỗng không nhận được thuộc tính chữ. */
function tt_doanTrong(cell) {
  if (cell.getNumChildren() > 0) {
    var e = cell.getChild(0);
    if (e.getType() === DocumentApp.ElementType.PARAGRAPH) {
      var pr = e.asParagraph();
      if (pr.getText() === '' && pr.getNumChildren() === 0) return pr;
    }
  }
  return cell.appendParagraph(' ');
}

/** Chèn ảnh từ Drive vào 1 ô bảng, co về chiều rộng cho trước. */
function tt_chenAnh(cell, ids, rongToiDa) {
  var da = 0, loi = [];
  (ids || []).forEach(function (idTho) {
    if (TT_SO_ANH_TOI_DA > 0 && da >= TT_SO_ANH_TOI_DA) return;
    var id = String(idTho == null ? '' : idTho).trim();
    if (!id) return;
    try {
      var blob = DriveApp.getFileById(id).getBlob();
      var img;
      try {
        img = tt_doanTrong(cell).appendInlineImage(blob);
      } catch (e1) {
        img = cell.appendImage(blob);          // phương án dự phòng
      }
      var w = img.getWidth(), h = img.getHeight();
      if (w > 0 && h > 0) {
        img.setWidth(rongToiDa);
        img.setHeight(Math.round(rongToiDa * h / w));
      }
      da++;
    } catch (e) {
      // In lỗi ra phiếu thay vì nuốt im lặng, để biết ngay vướng ở đâu
      loi.push(id.slice(0, 10) + '... ' + (e.message || e));
    }
  });
  if (!da) {
    tt_doanO(cell, loi.length ? ('Không chèn được ảnh: ' + loi.join(' | ')) : '(không có ảnh)', false, 8);
  }
  return { chen: da, loi: loi };
}

function tt_thuMucBaoCao() {
  var goc = tt_timHoacTao(DriveApp.getRootFolder(), TT_THU_MUC_GOC);
  return tt_timHoacTao(goc, 'Bao cao');
}

function tt_docSangPdf(doc, tenFile) {
  // Dọn đoạn trống đầu tài liệu. Phải làm ở đây, khi body đã có nội dung —
  // Docs không cho xoá đoạn văn cuối cùng còn lại của một section.
  try {
    var body = doc.getBody();
    if (body.getNumChildren() > 1) {
      var dau = body.getChild(0);
      if (dau.getType() === DocumentApp.ElementType.PARAGRAPH &&
          dau.asParagraph().getText() === '') {
        dau.removeFromParent();
      }
    }
  } catch (e) { /* không dọn được thì thừa 1 dòng trống, không sao */ }

  doc.saveAndClose();
  var tam = DriveApp.getFileById(doc.getId());
  var pdf = tam.getAs('application/pdf').setName(tenFile + '.pdf');
  var luu = tt_thuMucBaoCao().createFile(pdf);
  tam.setTrashed(true);
    return tt_moChiaSe({ ok: true, url: luu.getUrl(), name: luu.getName() });
}

/** Google Docs -> .docx. Apps Script không getAs docx được, phải qua link export. */
function tt_docSangWord(doc, tenFile) {
  try {
    var body = doc.getBody();
    if (body.getNumChildren() > 1) {
      var dau = body.getChild(0);
      if (dau.getType() === DocumentApp.ElementType.PARAGRAPH &&
          dau.asParagraph().getText() === '') dau.removeFromParent();
    }
  } catch (e) {}
  doc.saveAndClose();
  var id = doc.getId();
  var blob = UrlFetchApp.fetch(
    'https://docs.google.com/document/d/' + id + '/export?format=docx',
    { headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() } }
  ).getBlob().setName(tenFile + '.docx');
  var f = tt_thuMucBaoCao().createFile(blob);
  DriveApp.getFileById(id).setTrashed(true);
    return tt_moChiaSe({ ok: true, url: f.getUrl(), name: f.getName() });
}

/** Bảng kiểu Word: viền mảnh, tiêu đề đậm nền xanh nhạt. */
function tt_bangWord(body, duLieu, rongCot, cotGiua) {
  var t = body.appendTable(duLieu);
  t.setBorderWidth(0.5);
  if (rongCot) rongCot.forEach(function (w, i) { try { t.setColumnWidth(i, w); } catch (e) {} });
  for (var r = 0; r < t.getNumRows(); r++) {
    for (var c = 0; c < t.getRow(r).getNumCells(); c++) {
      var o = t.getRow(r).getCell(c);
      o.setPaddingTop(2).setPaddingBottom(2).setPaddingLeft(4).setPaddingRight(4);
      o.editAsText().setAttributes({ FONT_FAMILY: 'Times New Roman',
                                     FONT_SIZE: r === 0 ? 11 : 10, BOLD: r === 0 });
      if (r === 0) o.setBackgroundColor('#e6f1fb');
      if (r === 0 || (cotGiua && cotGiua.indexOf(c) >= 0)) {
        o.getChild(0).asParagraph().setAlignment(DocumentApp.HorizontalAlignment.CENTER);
      }
    }
  }
  return t;
}

/** Ghi chú tóm tắt của 1 khoa: gộp tiêu chí không đạt và không đánh giá được. */
function tt_ghiChuKhoa(k) {
  var ds = [];
  (k.loi || []).forEach(function (l) {
    ds.push('TC ' + l.maTc + ': ' + (l.ghiChu || 'chưa đạt'));
  });
  (k.kad || []).forEach(function (x) {
    ds.push('TC ' + x.maTc + ': ' + (x.ghiChu || 'không đánh giá được'));
  });
  return ds.join('; ');
}

/** Một khối minh chứng: tiêu đề tiêu chí, ghi chú, và ảnh.
 *  Bố cục do TT_ANH_ROI_HANG quyết định. */
function tt_khoiMinhChung(body, tieuDe, nhanGhiChu, ghiChu, anhIds, kemAnh) {
  var TONG = 484;                                  // bề ngang dùng được của trang
  var nen = '#f4f8fc';

  if (TT_ANH_ROI_HANG) {
    var b1 = body.appendTable([['']]);
    var o1 = b1.getCell(0, 0);
    o1.clear();
    tt_doanO(o1, tieuDe, true);
    tt_doanO(o1, nhanGhiChu + ': ' + (ghiChu || '(không ghi)'), false);
    if (kemAnh) tt_chenAnh(o1, anhIds, Math.min(TT_RONG_ANH, 470));
    b1.setBorderWidth(0.5);
    try { b1.setColumnWidth(0, TONG); } catch (e) {}
    o1.setBackgroundColor(nen);
    o1.setPaddingTop(5).setPaddingBottom(5).setPaddingLeft(6).setPaddingRight(6);
    return b1;
  }

  var rongAnh = Math.min(TT_RONG_ANH, 320);
  var cotPhai = rongAnh + 14;
  var cotTrai = Math.max(150, TONG - cotPhai);

  var b2 = body.appendTable([['', '']]);
  var trai = b2.getCell(0, 0), phai = b2.getCell(0, 1);
  trai.clear(); phai.clear();
  tt_doanO(trai, tieuDe, true);
  tt_doanO(trai, nhanGhiChu + ': ' + (ghiChu || '(không ghi)'), false);
  if (kemAnh) tt_chenAnh(phai, anhIds, rongAnh);
  else tt_doanO(phai, ' ');
  b2.setBorderWidth(0.5);
  try { b2.setColumnWidth(0, cotTrai); b2.setColumnWidth(1, cotPhai); } catch (e) {}
  [trai, phai].forEach(function (c) {
    c.setBackgroundColor(nen);
    c.setPaddingTop(4).setPaddingBottom(4).setPaddingLeft(5).setPaddingRight(5);
  });
  return b2;
}

// ===== XUẤT BÁO CÁO TỔNG HỢP RA WORD (theo mẫu của khoa) =====
function tt_xuatWordTongHop(thang) {
  var dl = tt_duLieuBaoCao(thang);
  if (!dl.tongHop.length) throw new Error('Chưa có phiếu nào trong kỳ đã chọn.');

  var tieuChi = tt_layDanhMuc().tieuChi;
  var tongTc = tieuChi.length;

  var ghiChuPhieu = {};
  dl.chiTiet.forEach(function (k) { ghiChuPhieu[k.maPhieu] = tt_ghiChuKhoa(k); });

  // Khoa có vấn đề xếp lên trước, sau đó theo tên
  var ds = dl.tongHop.slice().sort(function (a, b) {
    var x = a.soKhong + a.soKad, y = b.soKhong + b.soKad;
    if (x !== y) return y - x;
    return String(a.khoa).localeCompare(String(b.khoa), 'vi');
  });

  var nhan = thang ? ('thang ' + thang) : 'tat ca';
  var doc = DocumentApp.create('BC tong hop tu truc - ' + nhan);
  var body = doc.getBody();
  body.setMarginTop(50).setMarginBottom(50).setMarginLeft(60).setMarginRight(50);

  var td = body.appendParagraph(
    'BÁO CÁO TỔNG HỢP KẾT QUẢ GIÁM SÁT QUẢN LÝ THUỐC TẠI CÁC KHOA LÂM SÀNG');
  td.setAttributes({ FONT_FAMILY: 'Times New Roman', FONT_SIZE: 14, BOLD: true });
  td.setAlignment(DocumentApp.HorizontalAlignment.CENTER);

  var pt = body.appendParagraph(thang
    ? ('Tháng ' + thang.slice(5) + '/' + thang.slice(0, 4))
    : 'Toàn bộ dữ liệu');
  pt.setAttributes({ FONT_FAMILY: 'Times New Roman', FONT_SIZE: 13, BOLD: true });
  pt.setAlignment(DocumentApp.HorizontalAlignment.CENTER);

  var p1 = body.appendParagraph('I. Kết quả tổng hợp theo khoa lâm sàng');
  p1.setAttributes({ FONT_FAMILY: 'Times New Roman', FONT_SIZE: 13, BOLD: true,
                     SPACING_BEFORE: 10, SPACING_AFTER: 6 });

  var b1 = [['STT', 'Khoa/TT', 'Tổng số tiêu chí', 'Đạt', 'Không đạt',
             'Không đánh giá được', 'Ghi chú']];
  ds.forEach(function (r, i) {
    b1.push([String(i + 1), r.khoa, String(tongTc), String(r.soDat),
             String(r.soKhong), String(r.soKad), ghiChuPhieu[r.maPhieu] || '']);
  });
  tt_bangWord(body, b1, [32, 118, 52, 34, 48, 58, 142], [0, 2, 3, 4, 5]);

  var p2 = body.appendParagraph('II. Danh sách chi tiết theo các tiêu chí kiểm tra');
  p2.setAttributes({ FONT_FAMILY: 'Times New Roman', FONT_SIZE: 13, BOLD: true,
                     SPACING_BEFORE: 12, SPACING_AFTER: 4 });
  var p2b = body.appendParagraph('PHỤ LỤC: Các tiêu chí giám sát');
  p2b.setAttributes({ FONT_FAMILY: 'Times New Roman', FONT_SIZE: 12, SPACING_AFTER: 6 });

  var theoTc = {};
  dl.chiTiet.forEach(function (k) {
    (k.loi || []).forEach(function (l) {
      if (!theoTc[l.maTc]) theoTc[l.maTc] = [];
      theoTc[l.maTc].push(k.khoa + ': ' + (l.ghiChu || 'chưa đạt'));
    });
    (k.kad || []).forEach(function (x) {
      if (!theoTc[x.maTc]) theoTc[x.maTc] = [];
      theoTc[x.maTc].push(k.khoa + ': ' + (x.ghiChu || 'không đánh giá được'));
    });
  });

  var b2 = [['Tiêu chí', 'Nội dung tiêu chí',
             'Số lượng khoa chưa đạt / chưa đánh giá được']];
  tieuChi.forEach(function (t) {
    var v = theoTc[t.maTc];
    b2.push(['TC' + t.maTc, t.maTc + '. ' + t.noiDung, v ? v.join('; ') : '0']);
  });
  tt_bangWord(body, b2, [46, 250, 188], [0]);

  body.appendParagraph('').setAttributes({ FONT_SIZE: 11 });
  var bk = body.appendTable([
    ['Người tổng hợp', 'Trưởng khoa Dược'],
    ['\n\n\n', '\n\n\n'],
    [TT_NGUOI_TONG_HOP, TT_TRUONG_KHOA_DUOC]
  ]);
  bk.setBorderWidth(0);
  for (var r2 = 0; r2 < 3; r2++) for (var c2 = 0; c2 < 2; c2++) {
    var o2 = bk.getRow(r2).getCell(c2);
    o2.setBackgroundColor(null);
    o2.editAsText().setAttributes({ FONT_FAMILY: 'Times New Roman', FONT_SIZE: 12,
                                    BOLD: (r2 === 0 || r2 === 2) });
    o2.getChild(0).asParagraph().setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  }

  return tt_docSangWord(doc, 'BC tong hop tu truc - ' + nhan);
}

// ===== XUẤT BÁO CÁO TỔNG HỢP (PDF, kèm ảnh minh chứng) =====
function tt_xuatPdfTongHop(thang, kemAnh) {
  var dl = tt_duLieuBaoCao(thang);
  if (!dl.tongHop.length) throw new Error('Chưa có phiếu nào trong kỳ đã chọn.');

  var nhan = thang ? ('thang ' + thang) : 'tat ca';
  var doc = DocumentApp.create('BC bang kiem tu truc - ' + nhan);
  var body = doc.getBody();
  body.setMarginTop(36).setMarginBottom(36).setMarginLeft(42).setMarginRight(42);

  tt_dongTieuDe(body, 'BỆNH VIỆN ĐẠI HỌC PHENIKAA', 10, false);
  tt_dongTieuDe(body, 'KHOA DƯỢC', 10, false);
  tt_dongTieuDe(body, 'BÁO CÁO TỔNG HỢP BẢNG KIỂM AN TOÀN QUẢN LÝ THUỐC TẠI TỦ TRỰC', 12, true);
  tt_dongThuong(body, thang ? ('Tháng ' + thang.slice(5) + '/' + thang.slice(0, 4)) : 'Toàn bộ dữ liệu', 10, true);
  tt_dongThuong(body, 'Số khoa đã kiểm tra: ' + dl.tong.soKhoa +
    '   |   Số phiếu: ' + dl.tong.soPhieu +
    (dl.tong.tbTyLe !== '' ? ('   |   Tỷ lệ đạt trung bình: ' + dl.tong.tbTyLe + '%') : ''), 10, true);

  // I. Tổng hợp theo khoa
  tt_dongTieuDe(body, 'I. TỔNG HỢP THEO KHOA', 11);
  var b1 = [['STT', 'Khoa / Trung tâm', 'Ngày', 'Người giám sát', 'Đạt', 'Không đạt', 'KAD', 'Tỷ lệ']];
  dl.tongHop.forEach(function (r, i) {
    b1.push([String(i + 1), r.khoa, r.ngay, r.nguoiGiamSat,
             String(r.soDat), String(r.soKhong), String(r.soKad),
             r.tyLe === '' ? '' : r.tyLe + '%']);
  });
  tt_dinhDangBang(body.appendTable(b1), [28, 150, 60, 100, 34, 52, 34, 46], 9);

  // II. Tần suất lỗi
  tt_dongTieuDe(body, 'II. TẦN SUẤT TIÊU CHÍ KHÔNG ĐẠT', 11);
  if (!dl.tanSuat.length) {
    tt_dongThuong(body, 'Không có tiêu chí nào không đạt trong kỳ.', 10);
  } else {
    var b2 = [['TC', 'Nội dung tiêu chí', 'Số khoa', 'Danh sách khoa']];
    dl.tanSuat.forEach(function (t) {
      b2.push([String(t.maTc), t.noiDung, String(t.soKhoa), t.dsKhoa.join(', ')]);
    });
    tt_dinhDangBang(body.appendTable(b2), [28, 230, 48, 198], 9);
  }

  // III. Chi tiết
  tt_dongTieuDe(body, 'III. CHI TIẾT KHÔNG ĐẠT VÀ MINH CHỨNG', 11);
  if (!dl.chiTiet.length) {
    tt_dongThuong(body, 'Không có nội dung không đạt.', 10);
  } else {
    dl.chiTiet.forEach(function (k) {
      if (!k.loi.length && !k.kad.length) return;
      tt_dongTieuDe(body, k.khoa + '  —  ngày ' + k.ngay +
        '  —  ' + k.loi.length + ' tiêu chí không đạt', 10);

      k.loi.forEach(function (l) {
        tt_khoiMinhChung(body, 'TC ' + l.maTc + ' — ' + l.noiDung,
                         'Ghi chú', l.ghiChu, l.anhIds, kemAnh);
      });

      if (k.kad.length) {
        tt_dongThuong(body, 'Tiêu chí không áp dụng: ' + k.kad.map(function (x) {
          return 'TC ' + x.maTc + ' (' + (x.ghiChu || 'không ghi lý do') + ')';
        }).join('; '), 9);
      }
    });
  }

  // Chữ ký
  var hn = new Date();
  tt_dongThuong(body, '', 10);
  var p = tt_dongThuong(body, 'Hà Nội, ngày ' + hn.getDate() + ' tháng ' +
    (hn.getMonth() + 1) + ' năm ' + hn.getFullYear(), 10);
  p.setAlignment(DocumentApp.HorizontalAlignment.RIGHT);
  var bk = body.appendTable([['NGƯỜI LẬP BÁO CÁO', 'TRƯỞNG KHOA DƯỢC'], ['', '']]);
  bk.setBorderWidth(0);
  for (var r = 0; r < 2; r++) for (var c = 0; c < 2; c++) {
    var cell = bk.getRow(r).getCell(c);
    cell.editAsText().setAttributes({ FONT_FAMILY: 'Arial', FONT_SIZE: 10, BOLD: r === 0 });
    cell.getChild(0).asParagraph().setAlignment(DocumentApp.HorizontalAlignment.CENTER);
    if (r === 1) cell.appendParagraph('\n\n');
  }

  return tt_docSangPdf(doc, 'BC bang kiem tu truc - ' + nhan);
}

// ===== XUẤT PHIẾU LẺ CỦA 1 KHOA =====
function tt_xuatPdfPhieu(maPhieu) {
  var d = tt_layPhieu(maPhieu);
  if (!d) throw new Error('Không tìm thấy phiếu ' + maPhieu);
  var tieuChi = tt_layDanhMuc().tieuChi;
  var ten = {}, nhomCua = {};
  tieuChi.forEach(function (t) { ten[t.maTc] = t.noiDung; nhomCua[t.maTc] = t.tenNhom; });

  var ph = d.phieu;
  var doc = DocumentApp.create('Phieu tu truc - ' + ph['khoa'] + ' - ' + ph['ngay_kiem']);
  var body = doc.getBody();
  body.setMarginTop(36).setMarginBottom(36).setMarginLeft(42).setMarginRight(42);

  // Đầu trang: tên đơn vị bên trái, mã phiếu bên phải.
  // Dựng thẳng từ mảng dữ liệu, không clear() rồi ghi đè — tránh nhân đôi nội dung.
  var bd = body.appendTable([
    ['BỆNH VIỆN ĐẠI HỌC PHENIKAA', 'Mã phiếu: ' + maPhieu],
    ['KHOA DƯỢC', '']
  ]);
  bd.setBorderWidth(0);
  try { bd.setColumnWidth(0, 290); bd.setColumnWidth(1, 194); } catch (e) {}
  for (var rh = 0; rh < 2; rh++) {
    for (var ch = 0; ch < 2; ch++) {
      var o = bd.getRow(rh).getCell(ch);
      o.setPaddingTop(0).setPaddingBottom(0).setPaddingLeft(0).setPaddingRight(0);
      o.setBackgroundColor(null);
      o.editAsText().setAttributes({ FONT_FAMILY: 'Arial', FONT_SIZE: ch === 0 ? 10 : 9, BOLD: ch === 0 });
      o.getChild(0).asParagraph().setAlignment(ch === 0
        ? DocumentApp.HorizontalAlignment.LEFT
        : DocumentApp.HorizontalAlignment.RIGHT);
    }
  }

  tt_dongTieuDe(body, 'BẢNG KIỂM AN TOÀN TRONG QUẢN LÝ THUỐC VÀ VẬT TƯ TIÊU HAO', 12, true);
  tt_dongThuong(body, 'tại các khoa lâm sàng / cận lâm sàng (Phụ lục 02)', 10, true);

  var bh = body.appendTable([
    ['Khoa / Trung tâm:', ph['khoa'] || '', 'Ngày kiểm tra:', ph['ngay_kiem'] || ''],
    ['Dược sĩ giám sát:', ph['nguoi_giam_sat'] || '', 'Điều dưỡng:', ph['dieu_duong'] || '']
  ]);
  bh.setBorderWidth(0);
  tt_dinhDangBang(bh, [96, 176, 76, 136], 9);
  for (var r = 0; r < bh.getNumRows(); r++) {
    for (var c0 = 0; c0 < 4; c0++) bh.getRow(r).getCell(c0).setBackgroundColor(null);
    bh.getRow(r).getCell(1).editAsText().setBold(false);
    bh.getRow(r).getCell(3).editAsText().setBold(false);
  }

  var bang = [['STT', 'Nội dung đánh giá', 'Kết quả', 'Ghi chú']];
  var nhomHT = '';
  d.chiTiet.sort(function (a, b) { return a.maTc - b.maTc; }).forEach(function (c) {
    if (nhomCua[c.maTc] !== nhomHT) { nhomHT = nhomCua[c.maTc]; bang.push(['', nhomHT, '', '']); }
    bang.push([String(c.maTc), ten[c.maTc] || '', c.ketQua, c.ghiChu || '']);
  });
  var t = body.appendTable(bang);
  tt_dinhDangBang(t, [30, 250, 80, 124], 9);
  for (var i = 1; i < t.getNumRows(); i++) {
    var row = t.getRow(i);
    if (row.getCell(0).getText() === '' && row.getCell(2).getText() === '') {
      row.getCell(1).editAsText().setBold(true);
      for (var c2 = 0; c2 < 4; c2++) row.getCell(c2).setBackgroundColor('#f1f3f4');
    } else if (row.getCell(2).getText() === TT_KHONG) {
      row.getCell(2).editAsText().setForegroundColor('#cf222e').setBold(true);
    }
  }

  tt_dongThuong(body, 'Tổng số tiêu chí đạt: ' + ph['so_dat'] +
    '     Không đạt: ' + ph['so_khong_dat'] +
    '     Không áp dụng: ' + ph['so_khong_ap_dung'] +
    (ph['ty_le_dat'] !== '' ? ('     Tỷ lệ đạt: ' + ph['ty_le_dat'] + '%') : ''), 10);
  if (ph['nhan_xet']) tt_dongThuong(body, 'Nhận xét chung: ' + ph['nhan_xet'], 10);
  if (ph['de_nghi']) tt_dongThuong(body, 'Đề nghị, kiến nghị: ' + ph['de_nghi'], 10);

  var loi = d.chiTiet.filter(function (c) { return c.ketQua === TT_KHONG; });
  if (loi.length) {
    body.appendPageBreak();
    tt_dongTieuDe(body, 'NỘI DUNG KHÔNG ĐẠT VÀ MINH CHỨNG', 11);
    loi.forEach(function (l) {
      tt_khoiMinhChung(body, 'TC ' + l.maTc + ' — ' + (ten[l.maTc] || ''),
                       'Ghi chú chi tiết lỗi', l.ghiChu, l.anhIds, true);
    });
  }

  var bk = body.appendTable([
    ['DƯỢC SĨ GIÁM SÁT', 'ĐIỀU DƯỠNG', 'TRƯỞNG KHOA/TT', 'TRƯỞNG KHOA DƯỢC'],
    ['\n\n', '\n\n', '\n\n', '\n\n'],
    [ph['nguoi_giam_sat'] || '', ph['dieu_duong'] || '',
     ph['truong_khoa'] || '', ph['truong_khoa_duoc'] || '']
  ]);
  bk.setBorderWidth(0);
  for (var r3 = 0; r3 < 3; r3++) for (var c3 = 0; c3 < 4; c3++) {
    var cell3 = bk.getRow(r3).getCell(c3);
    cell3.editAsText().setAttributes({ FONT_FAMILY: 'Arial', FONT_SIZE: 8, BOLD: r3 === 0 });
    cell3.getChild(0).asParagraph().setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  }

  return tt_docSangPdf(doc, 'Phieu tu truc - ' + (ph['khoa'] || '') + ' - ' + (ph['ngay_kiem'] || ''));
}

/** Ép các cột ngày/giờ về định dạng Văn bản thuần.
 *  Chạy lại được nhiều lần, không hỏng dữ liệu cũ. */
function tt_epCotVanBan() {
  var sh = tt_ss().getSheetByName(TT_SHEET_PHIEU);
  if (!sh) return;
  var n = Math.max(sh.getMaxRows(), 500);
  ['ngay_kiem', 'thang', 'gio_bat_dau', 'gio_ket_thuc'].forEach(function (ten) {
    var i = TT_COLS_PHIEU.indexOf(ten);
    if (i >= 0) sh.getRange(1, i + 1, n, 1).setNumberFormat('@');
  });
}

/** Chạy hàm này rồi mở Execution log để xem dữ liệu đang được lưu ra sao. */
function tt_kiemTraDuLieu() {
  var rows = tt_docBang(TT_SHEET_PHIEU);
  var out = ['Tổng số phiếu trong sheet: ' + rows.length];
  rows.forEach(function (r) {
    out.push('- ' + r['ma_phieu'] +
      ' | khoa = ' + r['khoa'] +
      ' | ngay_kiem thô = "' + r['ngay_kiem'] + '" (kiểu ' +
        (Object.prototype.toString.call(r['ngay_kiem']) === '[object Date]' ? 'Ngày' : typeof r['ngay_kiem']) + ')' +
      ' | cột thang thô = "' + r['thang'] + '"' +
      ' | THÁNG DÙNG ĐỂ LỌC = ' + tt_thangCua(r));
  });
  var s = out.join('\n');
  Logger.log(s);
  return s;
}

/** Chẩn đoán ảnh của 1 phiếu. Chạy hàm này rồi mở Execution log.
 *  Cách dùng: sửa maPhieu bên dưới thành mã phiếu thật rồi bấm Run. */
function tt_kiemTraAnh() {
  var maPhieu = '';                    // <-- dán mã phiếu vào đây, ví dụ 'TT-20260829-101010'

  var out = [];
  if (!maPhieu) {
    var ds = tt_docBang(TT_SHEET_PHIEU);
    out.push('Chưa điền maPhieu. Các phiếu đang có:');
    ds.forEach(function (r) {
      out.push('   ' + r['ma_phieu'] + '  |  ' + r['khoa'] + '  |  ' + tt_ngayChuoi(r['ngay_kiem']));
    });
    Logger.log(out.join('\n'));
    return out.join('\n');
  }

  var d = tt_layPhieu(maPhieu);
  if (!d) { Logger.log('Không tìm thấy phiếu ' + maPhieu); return 'Không tìm thấy phiếu'; }

  out.push('Phiếu ' + maPhieu + ' — khoa ' + d.phieu['khoa']);
  d.chiTiet.forEach(function (c) {
    if (!c.anhIds.length) return;
    out.push('TC ' + c.maTc + ' — ' + c.anhIds.length + ' ảnh:');
    c.anhIds.forEach(function (id) {
      try {
        var f = DriveApp.getFileById(id);
        var b = f.getBlob();
        out.push('   OK   ' + id + '  |  ' + f.getName() +
                 '  |  ' + b.getContentType() +
                 '  |  ' + Math.round(b.getBytes().length / 1024) + ' KB' +
                 '  |  chủ sở hữu: ' + (f.getOwner() ? f.getOwner().getEmail() : '?'));
      } catch (e) {
        out.push('   LỖI ' + id + '  ->  ' + (e.message || e));
      }
    });
  });
  if (out.length === 1) out.push('Phiếu này không có ảnh nào được lưu trong cột anh_ids.');

  var s = out.join('\n');
  Logger.log(s);
  return s;
}

/** Chạy THẲNG trong trình chỉnh sửa Apps Script (chọn hàm -> Run).
 *  Hàm chạy bằng code mới nhất, không phụ thuộc version đã deploy —
 *  dùng để phân biệt "code sai" với "web app đang chạy version cũ". */
function tt_thuXuatPhieuGanNhat() {
  var ds = tt_docBang(TT_SHEET_PHIEU);
  if (!ds.length) { Logger.log('Chưa có phiếu nào trong sheet.'); return 'Chưa có phiếu nào.'; }
  var ma = String(ds[ds.length - 1]['ma_phieu']).trim();
  var kq = tt_xuatPdfPhieu(ma);
  var tb = 'Đã xuất phiếu ' + ma + '\nMở file: ' + kq.url;
  Logger.log(tb);
  return tb;
}

// ============================================================
//  XÓA PHIẾU TỦ TRỰC (cascade: xóa phiếu + toàn bộ chi tiết)
//  Dán thêm vào CUỐI file TuTruc.gs. Không sửa gì code cũ.
//  Tận dụng tt_docBang, tt_ngayChuoi, tt_xoaPhieuCu đã có sẵn.
// ============================================================

/** Danh sách phiếu để hiển thị + chọn xóa (mới nhất lên đầu). */
function tt_dsPhieuXoa() {
  return tt_docBang(TT_SHEET_PHIEU).map(function (r) {
    return {
      maPhieu: String(r['ma_phieu'] || '').trim(),
      ngay: tt_ngayChuoi(r['ngay_kiem']),
      khoa: String(r['khoa'] || ''),
      giamSat: String(r['nguoi_giam_sat'] || ''),
      soKhong: r['so_khong_dat'],
      tyLe: r['ty_le_dat']
    };
  }).filter(function (p) { return p.maPhieu; })
    .sort(function (a, b) { return a.ngay < b.ngay ? 1 : -1; });
}

/** Xóa 1 phiếu + tất cả dòng chi tiết cùng ma_phieu.
 *  Dùng lại tt_xoaPhieuCu (đã xóa ở cả TUTRUC_PHIEU lẫn TUTRUC_CHITIET). */
function tt_xoaPhieu(maPhieu) {
  maPhieu = String(maPhieu || '').trim();
  if (!maPhieu) return { ok: false, msg: 'Thiếu mã phiếu.' };

  var lock = LockService.getScriptLock();
  try { lock.waitLock(20000); } catch (e) { return { ok: false, msg: 'Hệ thống đang bận, thử lại sau.' }; }
  try {
    // đếm trước để báo lại cho người dùng
    var conP = tt_docBang(TT_SHEET_PHIEU).filter(function (r) {
      return String(r['ma_phieu']).trim() === maPhieu;
    }).length;
    var conC = tt_docBang(TT_SHEET_CHITIET).filter(function (r) {
      return String(r['ma_phieu']).trim() === maPhieu;
    }).length;

    if (conP === 0 && conC === 0) return { ok: false, msg: 'Không tìm thấy phiếu ' + maPhieu };

    tt_xoaPhieuCu(maPhieu);   // xóa cascade cả 2 sheet

    return { ok: true, msg: 'Đã xóa phiếu ' + maPhieu + ' (kèm ' + conC + ' dòng chi tiết).' };
  } finally {
    lock.releaseLock();
  }
}

// ============================================================
//  CHIA SẺ FILE XUẤT RA — "ai có link đều xem được"
//  Dán thêm vào CUỐI file TuTruc.gs, RỒI sửa 2 dòng như hướng dẫn.
// ============================================================

// Đặt quyền "bất kỳ ai có link đều XEM" cho 1 file theo URL (hoặc id).
// Trả lại chính url để tiện gọi lồng: return tt_moChiaSe(kq).
function tt_moChiaSe(kq) {
  try {
    var url = (kq && kq.url) ? kq.url : String(kq || '');
    var m = url.match(/[-\w]{25,}/);
    if (m) {
      DriveApp.getFileById(m[0])
        .setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    }
  } catch (e) { /* không đặt được thì bỏ qua, không chặn việc xuất file */ }
  return kq;
}

