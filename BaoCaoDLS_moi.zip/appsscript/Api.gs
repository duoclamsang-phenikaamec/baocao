/**
 * ============================================================
 *  Api.gs — CỔNG API JSON cho giao diện chạy trên GitHub Pages
 *  Dán thành FILE MỚI trong cùng dự án Apps Script (cạnh Code.gs, TuTruc.gs).
 *  KHÔNG sửa logic code cũ. Link web app cũ (doGet) vẫn chạy song song.
 *
 *  Giao diện gửi:  POST  {fn:'tenHam', args:[...], key:'ma truy cap'}
 *  Server trả:     {ok:true, data:...}   hoặc   {ok:false, error:'...'}
 * ============================================================
 */

// Các hàm giao diện được phép gọi (danh sách trắng — hàm khác bị chặn)
var API_DS_HAM = [
  // Code.gs
  'getDanhMuc', 'luuCanThiep', 'luuHoatDong', 'getBaoCao', 'xuatExcel',
  'getGoiYThuoc', 'getGoiYNVYT', 'getChamCongTuan', 'luuChamCong',
  'getSoBNThang', 'luuSoBNThang', 'luuRaDon', 'getGoiYThuocRaDon',
  'getSoDonThang', 'luuSoDonThang', 'getChuyenKhoa',
  // TuTruc.gs
  'tt_layDanhMuc', 'tt_taoMaPhieu', 'tt_taiAnh', 'tt_xoaAnh', 'tt_luuPhieu',
  'tt_layPhieu', 'tt_danhSachPhieu', 'tt_duLieuBaoCao', 'tt_xuatWordTongHop',
  'tt_xuatPdfTongHop', 'tt_xuatPdfPhieu', 'tt_dsPhieuXoa', 'tt_xoaPhieu'
];

// Hàm ghi dữ liệu: xếp hàng từng lượt một (tránh dòng trùng khi bấm nhanh, ví dụ ô chấm công)
// tt_luuPhieu / tt_xoaPhieu đã tự khoá bên trong nên không cần ở đây.
var API_HAM_GHI_CAN_KHOA = ['luuCanThiep', 'luuHoatDong', 'luuChamCong',
                            'luuRaDon', 'luuSoBNThang', 'luuSoDonThang'];

// Hàm đọc danh mục: lưu cache phía server (giây). Danh mục ít đổi nên đọc lại sheet là phí.
var API_CACHE_GIAY = {
  getDanhMuc: 600, tt_layDanhMuc: 600, getChuyenKhoa: 600,
  getGoiYThuoc: 600, getGoiYNVYT: 600
};

// Sau khi lưu thì xoá cache gợi ý liên quan, để tên thuốc / NVYT mới hiện ngay
var API_XOA_CACHE_SAU = {
  luuCanThiep: ['getGoiYThuoc', 'getGoiYNVYT']
};

// ===== ĐIỂM VÀO API =====
function doPost(e) {
  var t0 = Date.now();
  try {
    var req = JSON.parse((e && e.postData && e.postData.contents) || '{}');

    var ma = PropertiesService.getScriptProperties().getProperty('API_KEY');
    if (ma && String(req.key || '') !== ma) {
      return api_tra_({ ok: false, error: 'UNAUTHORIZED' });
    }

    var fn = String(req.fn || '');
    if (fn === 'ping') return api_tra_({ ok: true, data: 'pong', ms: Date.now() - t0 });

    var args = Array.isArray(req.args) ? req.args : [];
    if (API_DS_HAM.indexOf(fn) < 0 || typeof globalThis[fn] !== 'function') {
      throw new Error('Hàm không được phép: ' + fn);
    }

    var data = api_goi_(fn, args);
    return api_tra_({ ok: true, data: data, ms: Date.now() - t0 });
  } catch (err) {
    return api_tra_({ ok: false, error: (err && err.message) || String(err) });
  }
}

function api_goi_(fn, args) {
  var cache = CacheService.getScriptCache();
  var ttl = API_CACHE_GIAY[fn];
  var ck = ttl ? api_khoaCache_(fn, args) : null;

  if (ck) {
    var c = cache.get(ck);
    if (c) { try { return JSON.parse(c); } catch (e) {} }
  }

  var data;
  if (API_HAM_GHI_CAN_KHOA.indexOf(fn) >= 0) {
    var lock = LockService.getScriptLock();
    lock.waitLock(20000);
    try { data = globalThis[fn].apply(null, args); }
    finally { lock.releaseLock(); }
  } else {
    data = globalThis[fn].apply(null, args);
  }

  if (ck) {
    try {
      var s = JSON.stringify(data);
      if (s.length < 90000) cache.put(ck, s, ttl);   // giới hạn ~100KB mỗi khoá
    } catch (e) {}
  }

  (API_XOA_CACHE_SAU[fn] || []).forEach(function (f) {
    cache.remove(api_khoaCache_(f, []));
  });
  return data;
}

function api_khoaCache_(fn, args) { return 'api:' + fn + ':' + JSON.stringify(args || []); }

function api_tra_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

// ===== MÚI GIỜ (gọi 1 lần, dùng lại) =====
// Code cũ gọi getSpreadsheetTimeZone() cho TỪNG Ô ngày khi lọc báo cáo — hàng nghìn lần.
// Hàm này chỉ hỏi Sheet 1 lần mỗi lượt chạy.
var __TZ_CACHE = null;
function tzNhanh_() {
  if (!__TZ_CACHE) {
    __TZ_CACHE = SpreadsheetApp.getActiveSpreadsheet().getSpreadsheetTimeZone() || 'Asia/Ho_Chi_Minh';
  }
  return __TZ_CACHE;
}

// ===== CÀI ĐẶT & TIỆN ÍCH (chạy tay từ trình soạn thảo) =====

/** Đặt mã truy cập. Sửa chuỗi MA bên dưới rồi bấm Run 1 lần.
 *  Nhân viên nhập mã này 1 lần trên trình duyệt, máy sẽ nhớ. */
function api_datMaTruyCap() {
  var MA = 'doi-ma-nay-truoc-khi-chay';
  PropertiesService.getScriptProperties().setProperty('API_KEY', MA);
  Logger.log('Đã đặt mã truy cập.');
  return 'Đã đặt mã truy cập.';
}

/** Xoá cache danh mục phía server (khi vừa sửa DM_ mà muốn thấy ngay). */
function api_xoaCache() {
  CacheService.getScriptCache().removeAll(
    Object.keys(API_CACHE_GIAY).map(function (f) { return api_khoaCache_(f, []); })
  );
  Logger.log('Đã xoá cache danh mục.');
  return 'Đã xoá cache danh mục.';
}

/** Tự xoá cache khi sửa tay bất kỳ sheet danh mục DM_...
 *  LƯU Ý: nếu dự án đã có hàm onEdit ở file khác, đổi tên hàm này
 *  và gọi api_suaDanhMuc_(e) từ onEdit sẵn có. */
function onEdit(e) { api_suaDanhMuc_(e); }
function api_suaDanhMuc_(e) {
  try {
    var ten = e.range.getSheet().getName();
    if (/^DM_/.test(ten)) api_xoaCache();
  } catch (x) {}
}
